Implementation details of the eleven evaluated baseline models

Inspected implementation and evidence snapshot, November 19, 2026 America/New_York.
Read workspace/reports/baseline_implementations_2026-11-19/baseline_model_implementation_reference.html or .md.
source_index.json records original paths and SHA-256 hashes for every included file.
No checkpoints or benchmark image packs are included. Historical launch scripts are source evidence, not automatic launch instructions.
A current recovered source file can differ from the older source hash inside a frozen plan. Preserve that version distinction.
