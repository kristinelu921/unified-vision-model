# Implementation details of the eleven evaluated baseline models

This reference describes the **11 baseline model families actually evaluated in this repository**, their selected Bench v2 recipes, earlier evaluated variants, and the implementation changes that affect reproducibility. The eleven are VisualCloze, Painter, VICT, GenLV, LaVin-DiT, PromptDiffusion, RelationAdapter, InstaManip, IMProv, Analogist, and LVM. JFLUX or Ours/TA is the comparison method and is not counted as a twelfth baseline.

The primary comparison uses 221 validation queries and 17,511 test queries under Bench v2 supervision v6. The older supervision-v5 evaluations are a separate experiment lineage. These are evaluations of released pretrained checkpoints, not newly reproduced pretraining runs. VICT additionally optimizes its encoder at test time; the other selected recipes keep learned weights fixed. All eleven families have saved validation measurements; the locally available terminal receipts verify full-test completion for six families. A saved configuration, a successful smoke test, and a completed test evaluation are different evidence levels.

**Record cutoff:** November 19, 2026, America/New_York. Status statements describe the saved local evidence inspected for this reference, rather than a live check of running machines. Exact runner and configuration copies, their SHA-256 hashes, prompts, manifests, and completion receipts accompany the reference in its source bundle. Inline source IDs resolve to the source index at the end.

# Model inventory and selected recipes

`P` is the number of demonstration input–target pairs. Candidate count is the number of generated predictions for one query. Padding a device batch does not create additional evaluated queries. The selected recipe is held constant across task categories; no category-by-category selection is implied.

| Model | Selected recipe | P | Saved test evidence |
| --- | --- | --- | --- |
| VisualCloze | visualcloze-p2 | 2 | Full test verified |
| Painter | painter-p1-depth-decoded | 1 | Full test verified |
| VICT | vict-p1-depth-decoded | 1 | Validation complete; test receipt absent |
| GenLV 101 Huge | genlv-cpu-reference | 1 | Full test verified |
| LaVin-DiT | lavin-dit-p8 | 8 | Validation complete; test receipt absent |
| PromptDiffusion | promptdiffusion-range-updated / A1 | 1 | Full test verified |
| RelationAdapter | relation-adapter-p1 | 1 | Validation complete; test receipt absent |
| InstaManip | instamanip-p3 | 3 | Validation complete; test receipt absent |
| IMProv | improv-cpu-reference-edge-sqrt | 1 | Full test verified |
| Analogist | analogist-p1 | 1 | Validation complete; test receipt absent |
| LVM 7B | lvm-p1 | 1 | Full test verified |

The selected-recipe names come from the frozen selection snapshot and the all-eleven configuration audit. `promptdiffusion-range-updated` is explicitly bound to runtime candidate `A1` and receipt name `promptdiffusion-a1`. LVM's full-test receipt uses the longer descriptive name `lvm_native_7b_fp16_p1_seed0_t1_topp09_topk50_one_candidate`. VisualCloze retains the P2 recipe name but its later test execution includes the documented decoder arithmetic correction. [S01] [S02] [S03] [S04]

# Shared data and evaluation implementation

## Dataset generations and immutable identities

The older `test_s64_px256_v5` pack contains 960 examples, 64 for each of 15 tasks, and has a pack ID beginning `48e0624`. It uses supervision v5. The separate lineage-A validation pack contains 128 queries across four tasks. The September P2 baseline evaluations used real, scrambled, grey, and oracle conditions, yielding 3,840 v5 test episodes and 512 lineage-A validation episodes per complete model run. These counts do not describe Bench v2. The repository also retains v4c and procedural packs; their presence does not make them interchangeable with either line. [S05] [S06]

The later all-eleven campaign freezes Bench v2 supervision **v6**, validation pack ID `8e139f91b083e0ae73b2ed81d8e235460ac2f37d`, and pack-manifest file SHA-256 `89f2501aa722cd121da12e33a24ac9037d5cf50df7627911b7f6ce22fcd6c49d`. Validation contains 13 tasks × 17 queries = 221. Test contains 26 task/dataset packs and 17,511 queries. Some historical launchers call a combined 27-pack, 17,732-query validation-plus-test plan a “test plan”; the independent test denominator remains 17,511. [S01] [S02] [S03]

Each pack contains `samples.json` and `samples.npz`. Image and rendered-target arrays are RGB `uint8 [N,256,256,3]`. Metadata supplies task, source, record identity, pack identity, supervision, and the render contract. Regional staging verifies the frozen manifest and file hashes before unpacking to node-local storage, commonly `/dev/shm`. Benchmark ground-truth sidecars contain the additional information needed for scoring, including depth endpoints, original point coordinates, void masks, inpainting masks, and individual BSDS annotations. These are scorer assets, not additional model conditioning.

## Episode construction and information boundaries

For each task-local query index `q`, the builder selects demonstrations from the query's source and excludes the query itself. The episode RNG is NumPy `default_rng([42, task_seed(task), q, P])`. Palette-family episodes draw their convention ID from the evaluation convention pool before drawing demonstration indices. `code_episode` codes demonstration targets and the query target jointly. The frozen plan binds the ordered records, convention ID, permitted image pixels, query target, and their hashes. The reconstruction step rejects a changed binding. [S07]

The model sees demonstration inputs, demonstration targets, and the query input. Text-capable methods additionally receive their declared task text or frozen permitted-input caption. The query target is used for episode coding, artifact verification, and scoring, but is not passed as the missing image to the inference forward. Some historical wrappers can read the full pack while assembling the episode; later target-isolated payloads restrict inference to the three permitted image fields. These two implementation boundaries should not be conflated.

Because `P` enters the seed and joint palette coding, changing demonstration count can change the demonstrations **and the coded target**. In the archived InstaManip P3-versus-P2 comparison, 66 of 221 targets changed. Consequently, a difference between P1 and P3 is a recipe comparison, not necessarily a controlled experiment changing context length alone. Query identity and target-pixel identity must both be checked. [S08]

Bench v2's selected recipes use the **real** condition. The older real/scrambled/grey/oracle arms remain historical controls. Repository corrections still apply to the older ledger: E26 found that palette-task scrambling re-coded outputs, requiring remeasurement of those controls; E25a parity statements retain their correction banner, and E26–E29 supersede older notes. [S05]

## Shared scoring

The base corrected-v3 metric release has SHA-256 `bd08e05f1d0e9dd077db683f4f124ac49a2c45cd0ec5728653bd1ad66cc13792` and protocol `bench_v2_PP2_CSA_seed1_AP_FIRST_v1`. The selected all-eleven campaign adds explicit versioned amendments around that frozen backend: signed-scale relative-depth evaluation; Painter/VICT native depth decoding; and IMProv's square-root edge confidence. It does not silently edit the base release. [S09] [S10]

| Task | Primary metric | Preferred direction |
| --- | --- | --- |
| colorization | lpips | lower |
| deblurring | lpips | lower |
| denoising | lpips | lower |
| edge_detection | ois_f | higher |
| face_landmarks | nme | lower |
| human_pose_2d | pck_torso_0.2 | higher |
| inpainting | lpips | lower |
| instance_segmentation | pq | higher |
| relative_depth | delta1_signed_scale | higher |
| saliency_detection | max_fbeta | higher |
| semantic_segmentation | miou | higher |
| super_resolution | lpips | lower |
| surface_normals | mean_deg | lower |

Appearance uses frozen LPIPS v0.1 with AlexNet, on CPU, with the network weights and package source recorded in the scorer identity. Inpainting is evaluated on the composite that preserves the original known pixels. PSNR and SSIM can be secondary diagnostics; they are not interchangeable with the selected LPIPS primary.

Semantic segmentation is evaluated by per-image class-agnostic region matching, with void excluded. Instance segmentation uses class-agnostic PQ and source void masks. The postprocessor decodes a prediction losslessly when **every pixel** is an exact member of the public 1,024-color codebook; otherwise it follows the frozen continuous-RGB decoder. This decision uses prediction pixels and the public codebook, not the target's class vocabulary. Keypoints are identity-agnostic; pose uses the dataset-specific torso normalization, while facial landmarks use the appropriate inter-ocular or inter-pupil normalization. Invalid predicted normals receive 180 degrees of error on valid ground-truth support. [S10] [S11]

Edge OIS is the best F-score on each image's 99-threshold curve, then averaged across queries. This differs from pooling all threshold counts across a dataset before computing a readout. The scorer retains the official matching implementation and individual BSDS annotators. The archived VICT aggregation correction is part of the source bundle; pooled edge diagnostics must not replace the mean per-query primary without being labeled. [S09] [S10] [S12]

The signed-depth variant fits `s*x+t` to the query's inverse-depth ground truth by least squares and allows negative `s`. It preserves the prediction-invalid mask, scored region, coverage, inverse-depth floor, and metric calculations. It then converts the aligned inverse depths back to depths and computes the fraction satisfying `max(pred/gt, gt/pred) < 1.25`. The **sign is selected using query ground truth at evaluation time**. This is an explicit sensitivity protocol, not an inference-time correction of the model's depth polarity. NYUv2 uses mapped crop rows 24 through 251 and the 0.001–10 m range; DIODE uses 0.6–350 m. [S10] [S13]

Every scored model prediction has a copy-input control. The six complete single-output test receipts each account for 17,511 predictions, 26 packs, and 35,022 prediction/control score pairs. Analogist instead retains eight predictions per query: its full-test requirement is 140,088 candidate images and 280,176 candidate/control score pairs. A score mean must retain the same query set and denominator; heterogeneous task metrics are not averaged into one raw “overall score.” [S04] [S14]

# VisualCloze

## Model and conditioning

The selected model is `VisualCloze/VisualClozePipeline-384` at revision `59c469d2772d927ffe55f3543c4d3bd556fd46a4`. The frozen baseline uses the custom Diffusers revision `0377f0c1b34e3ff313d41edad1bd79c2ed8bb5ec`. Its inference components are the VisualCloze generation pipeline, FLUX-family transformer, AutoencoderKL, text encoders, and FlowMatch Euler scheduler supplied by that pinned release. The actual model asset tree is verified against a complete checksum list; a similarly named FLUX checkpoint is not a substitute. [S15] [S16]

P2 builds three rows and two columns: `(demo input 1, demo target 1)`, `(demo input 2, demo target 2)`, `(query input, missing target)`. Each native tile is 384 pixels. The pipeline constructs the layout conditioning and mask for the missing target. The selected runner uses 13 frozen task instructions and `content_prompt=""`. The layout prompt, task prompt, and content prompt pass through the release's text preprocessing and encoding at maximum sequence length 512. Task embeddings are prepared on CPU, cached, and then supplied to the device pipeline.

The selected settings are BF16, 30 FlowMatch Euler steps, guidance 30.0, one generated output, and a CPU generator reset to seed 0 for each query. The historical P2 runner uses a padded batch of two on eight global/addressable TPU devices, with a `(2,4)` mesh named `data` and `model`. Large transformer parameters are sharded on the chosen large dimension, and XLA FlashAttention uses the explicitly configured block size 1,024. Padding records are excluded from completion counts. The raw 384-pixel tile is saved, then resized to 256 pixels with Pillow LANCZOS for scoring. [S15]

## Numerical repair used by the completed test

A later replay exposed finite decoder inputs followed by 884,736 nonfinite decoded values. The recorded failure first appeared in `decoder.up_blocks.3`; isolated CPU and TPU decoding of the saved latent was finite, so an isolated one-image success did not qualify the full execution sequence. [S17]

The completed test wrapper changes **only `decoder.up_blocks.3.resnets.2.norm2` arithmetic** at the VAE decode boundary: input, affine weight, and bias are converted to FP32; `torch.nn.functional.group_norm` uses the existing group count and epsilon; its result is cast back to the input dtype. The original method is restored afterward. A raw decoded-tensor finiteness check runs before conversion to pixels. [S18]

The November 12 qualification reports two fresh 221-query validation executions with identical predictions to each other, all raw outputs finite, and all selected-contract scores finite. Inputs, targets, weights, prompts, and sampling settings were retained. **All 221 output images changed relative to the older archive**, and only 15 query scores were exactly equal. Thus this is a qualified numerical repair, not archived-output parity. Its full signed score deltas remain in the receipt. The full-test completion receipt verifies 17,511/17,511 queries on November 14. [S19] [S04]

## Other evaluated variants and unresolved distinctions

P1, P2, P4, and P8 have separate saved validation variants. They are native multi-pair grids. The older evaluation and subsequent recovery experiments also distinguish task prompts, neutral prompts, empty captions, `None` captions, and layout-string handling. The audit's recommendation to replace empty content with `None` must not be retroactively described as the selected P2 implementation: the saved selected runner uses an empty string. Cross-backend CUDA/TPU equality is not established by the successful repaired TPU run. [S20] [S21]

# Painter

## Architecture and checkpoint

Painter uses `painter_vit_large_patch16_input896x448_win_dec64_8glb_sl1` from source revision `97200aa029bab2e61ea5b4ce627534e35f152b23`. The checkpoint has SHA-256 `1bdd60ce013e82253e2a031726f36d07587947438b0e561d4338d6f0c1113f44` and size 1,483,011,937 bytes. Loading checks both size and hash and rejects missing or unexpected model keys. [S22]

The source constructor uses a 896×448 image, 16×16 patches, embedding width 1,024, 24 transformer blocks, 16 attention heads, MLP ratio 4, QKV bias, relative positions, LayerNorm epsilon `1e-6`, and decoder embedding width 64. The constructor records window size 14 and drop-path rate 0.1; inference calls `eval()`. The exact window-block expression is retained in the source snapshot rather than normalized into an assumed schedule. [S23]

## Input preparation and forward pass

The selected P1 input vertically concatenates the demonstration input and query, each resized to 448×448 with bicubic interpolation. The demonstration target is nearest-neighbor resized and duplicated into both target halves; the bottom half is masked, so this duplicate is a finite placeholder, not a query target. Arrays become float32 in `[0,1]`, then use ImageNet mean `(0.485,0.456,0.406)` and standard deviation `(0.229,0.224,0.225)`, stored as float32 constants in the selected TPU primitive.

The selected TPU recipe uses float32 model execution and batches padded to four. There are 56×28 = 1,568 patch positions, with the lower 784 positions masked. The batch axis is sharded across the data mesh. `forward_encoder` and `forward_decoder` produce the canvas prediction; only rows 448 onward are returned. The output is denormalized, multiplied by 255, clipped, nearest-neighbor resized to 256×256, and converted to `uint8` by truncation. These interpolation and quantization boundaries are part of the recipe. [S22]

## Depth decoding and separate adapters

`painter-p1-depth-decoded` retains the saved RGB prediction and applies the versioned depth decoder during scoring. For each pixel, `depth = mean(R,G,B)/255`; positive depth is converted to `1/depth`; exactly black RGB is preserved as invalid. A fixed positive unit scale is absorbed by depth alignment. No demonstration endpoint, query target, detector, or fitted inference parameter enters this conversion. Copy-input controls use the generic decoder. [S24]

This selected correction is separate from the **native-depth bridge experiment**, which changes demonstration encoding to the released metric-depth convention and retains floating native-depth output before inverse-meter conversion. Native semantic, instance, and pose adapters are likewise separate conditions. The pose experiment additionally uses demonstration joint metadata and an external image-only person detector. Those results must not be attributed to generic P1 Painter. [S21]

## Validation and execution history

The later TPU qualification replays all 221 episode bindings and checks four representative outputs, finite raw values, and exact repeatability on a v4-8 with Torch/XLA 2.7.0. The qualification is scoped to the archived float32 batch-four primitives on that hardware, not equality with every older TPU backend. The complete test receipt verifies all 17,511 predictions and scores. A separate 221-query CPU float32 reference uses the official boundary arithmetic and remains a distinct condition. [S25] [S04]

The September v5 P2 and later P4 single-prompt adaptations perform separate native P1 forwards and average predictions; they do not enlarge Painter into a native multi-pair transformer. Surface-normal and other unsupported-task failures remain model/evaluation findings, not repairs achieved by the depth decoder. [S06] [S21]

# VICT

## Architecture and adaptation objective

VICT uses official source revision `56c395244223ae464d754cae1ef2cad073cd48ac` and the same Painter architecture and checkpoint. The selected condition is `VICT@60step_encoder_noaug_R0`: P1, batch one, 60 test-time encoder updates for each query. All parameters whose names do not begin with `decoder` are trainable; decoder parameters remain frozen. The model weights are reset from CPU copies before every query, and all tensor optimizer state is zeroed. [S26]

The adaptation step first predicts the masked query target from the support pair and query input. It constructs a cycle target by concatenating the true support label and the predicted query-target half. A second encoder/decoder pass reconstructs the support side under the reverse mask. The official `forward_loss` with smooth-L1 configuration supplies the cycle objective. The query's true target is not an optimization target. The pseudo-query prediction is concatenated without a detach in the archived adaptation function, preserving the computational graph through the cycle. [S27]

## Optimizer, precision, and random state

The selected optimizer is `torch_xla.amp.syncfree.AdamW` with learning rate `1e-6`, betas `(0.9,0.999)`, epsilon `1e-8`, and zero weight decay. Forward/backward adaptation uses XLA BF16 autocast, activation checkpointing, and a fresh GradScaler with initial scale 65,536 for each query. Every iteration zeros gradients, computes loss, scales/backpropagates, unscales, checks the sentinel gradient and overflow flags, steps the optimizer, updates the scaler, and synchronizes device work. The receipt saves losses, finite gradient norms, overflow flags, step timings, and final scale. A nonzero finite sentinel-parameter change is required as evidence that an update occurred. [S27] [S28]

The run seeds Torch and NumPy with 0 at process initialization; model and optimizer reset do **not** imply that the global random stream is reset per query. Ordered replay is therefore material to recovery. The adaptation function calls `make_canvas(..., seed=None)` on every step, selecting the full-image resize path without crop/flip augmentation. The file also contains augmentation utilities, but those are not exercised by this R0 path. [S26] [S28]

## Preprocessing and output boundaries

Inputs use bicubic 448 resizing and ImageNet normalization. Demonstration-target interpolation is bicubic for relative depth, pose, and facial landmarks, and nearest otherwise. At inference, the lower 448-pixel target half is denormalized and clipped to `[0,255]`; it is then resized to 256. Output interpolation is nearest for instance segmentation, pose, and face landmarks; bilinear for depth, semantic segmentation, edges, saliency, and normals; bicubic for the remaining appearance tasks. The selected archived implementation clips **before** resizing and truncates to `uint8`. [S26]

An independent recovery comparison studied the released restoration boundary order, including resize before final clipping. Three sequential CPU float32 60-update fixtures matched the corrected reference's losses, model/optimizer states, raw outputs, pixels, and continuing random state. This does not establish that the archived R0 TPU runner silently acquired the corrected boundary. The selected depth-scored recipe uses the same saved-RGB reciprocal-depth adapter as Painter. [S21] [S24]

## Run coverage and distinctions

The 221-query selected validation is archived. The campaign preserves 1,152 test predictions from an earlier attempt and records ordered replay and later recovery/scoring work. No local terminal full-test completion receipt was found for VICT in the inspected campaign, so it is not included among the six verified complete tests. The 60-step fixed-learning-rate recipe is also distinct from the paper appendix's 100-step task-tuned settings; those settings are not an implementation change in this selected run. [S03] [S21]

# GenLV 101 Huge

## Architecture and exact weights

The model is the extended 101-task `xrestormer_prompt_crossattn_huge`, using `huge-checkpoint-49.pth`. The checkpoint hash is `09e110d8c0781ba40848b49bf40c759daaa5eb1a6d4a9c959f5a75877d467ccc`; the selected loader requires size 2,457,130,637 bytes and strict loading. The audited checkpoint contains 1,586 tensors, and the instantiated network has 204,592,220 parameters. A source comment advertising a different approximate parameter count does not override the instantiated architecture. [S29] [S21]

The Huge constructor sets main width 80, block counts `[6,8,8,12]`, and eight refinement blocks. Inherited settings include window size 8, heads `[1,2,4,8]`, FFN expansion 2.66, no convolution/linear bias where configured, and WithBias normalization. The prompt key/value encoder has the released width 32 and projects into the main latent width. The network uses hierarchical restoration blocks and prompt-conditioned spatial cross-attention. The official source is hash-pinned to `335170a288a224b181b90b579d4321af749a4da7e3f1d8afc181f10cbbc29bac`. [S30]

## Inference implementation

P1 takes exactly three RGB `uint8 [256,256,3]` arrays: demonstration input, demonstration target, and query input. Preprocessing reverses RGB to BGR, casts to float32, divides by 255, and transposes to contiguous NCHW. It does not apply ImageNet normalization. The forward call is `model(imgs=[demo_input, demo_target, query_input, query_input], input_is_list=True)`: the fourth element is an unused query-input placeholder rather than ground truth. No text or latent-sampling interface is used. [S29]

The selected recipe executes CPU float32, batch one, Torch seed 0, eight intra-op threads, and one inter-op thread. It is deterministic inference with the model frozen and in evaluation mode. CPU execution ran on the selected TPU VM's host; the presence of a TPU in the allocation does not make this model execution a TPU calculation. Test work is divided by global query ordinal modulo eight into eight independent CPU shards. Episode and output hashes gate resumption. [S31]

Postprocessing multiplies float output by 255, clips to `[0,255]`, converts first to integer then `uint8`, transposes to HWC, and reverses BGR back to RGB. It performs no channel/sign search and no additional spatial resize. The file includes an optional bounded CPU prompt-feature cache keyed by complete batch pixels, weights, source, environment, precision, and seeds; the selected test forward calls `predict_raw` directly and does not install that cache. [S29] [S31]

## Other variants and completion

Earlier TPU P1 and historical P2 ensembles remain separate. The complete CPU validation comparison changed category means in both directions relative to the older TPU execution, while copy controls matched. The selected full test completes all 17,511 queries and scores across 26 packs. Depth polarity and normal coordinate conventions remain unresolved for this checkpoint; the repository did not adopt an evaluation-target-selected channel permutation or substitute task-fine-tuned weights. [S21] [S04]

# LaVin-DiT

## Architecture and assets

LaVin-DiT uses `LaVinDiT_3B_2` from source `f3728580115a4efbcd38d2279f1dbd868297b05e`, weights revision `908f27447c65a95ba480ead9ef30f59965817593`. The constructor has 22 blocks, hidden width 2,304, 32 attention heads, KV grouping 4, and spatial patch size 2×2. Head width is 72. It couples the DiT with `AutoencoderKLSTVAE`. The source float checkpoint hashes and the separately recorded BF16 conversion hashes are both retained. [S32] [S33]

The selected archived recipe is native P8. Each of the 17 frames is resized independently to 512×512 using torchvision v2 bicubic resize with antialiasing and normalized to `[-1,1]`. The frame order is `x1,y1,…,x8,y8,query`. The stacked condition has shape `[1,3,17,512,512]`, then is rearranged so the STVAE encodes the frames independently. Its posterior is sampled; the latent transform is `(sample - 0.032470703125) * 1.08936170213`. The inverse transform is used before decoding. [S34]

## Sampling and the exact random-stream distinction

The flow state has shape `[1,C,1,64,64]`, is duplicated for the guidance implementation, and is integrated with guidance 1.5. The “20 steps” setting is the following **20 time points, giving 19 Euler intervals**:

```text
0.0000, 0.0056, 0.0111, 0.0167, 0.0222,
0.0278, 0.0333, 0.0389, 0.0444, 0.0500,
0.0524, 0.0730, 0.1148, 0.1777, 0.2618,
0.3671, 0.4936, 0.6412, 0.8100, 1.0000
```

`torchdiffeq.odeint` uses the Euler method, with recorded `atol=[1e-6]` and `rtol=[1e-3]`; the fixed grid defines the Euler updates. Conditional conditioning contains the full latent sequence. Null conditioning contains a zero frame followed by the query frame. The default selected reference route uses the official conditional/null guidance method. A batched-guidance alternative exists, but admission requires its own exact-output gate; algebraic equivalence alone does not identify which route was executed. [S34]

The recovered **archived selected runner initializes a CPU generator to seed 0 for VAE posterior noise and initializes a second CPU generator to seed 0 for the initial flow noise**. Its named contract is `cpu_generator_seed0_per_draw_v1`. Later review notes propose using one advancing stream to match the released sequence more closely. That proposed correction is a different condition and must not be described as already present in the archived P8 outputs. This is a particularly important distinction because all samples can remain finite while the stochastic computation changes. [S34] [S21]

The main execution and STVAE are BF16. The loader tolerates only enumerated training-only VAE loss/discriminator/LPIPS prefixes, rejects missing inference parameters, and strictly matches the DiT state. Host-side initialization is serialized where needed to avoid simultaneous checkpoint loads exhausting memory; the source labels this an initialization-timing change. Native RGB output is converted to `uint8`, saved at 512, and LANCZOS-resized to 256 for scoring. [S34]

## Variants and coverage

P1, P2, P4, and P8 have archived 221-query validation results; P8 is selected. Multi-rank execution records rank output signatures and repeat agreement. The P8 validation archive is complete, but the latest inspected remaining-four audit has no terminal 17,511-query test receipt. Resource-loss and setup records are not test completions. The CPU/reference and TPU RNG or kernel differences remain separate from matching episode inputs. [S20] [S14] [S35]

# PromptDiffusion

## Components and condition structure

PromptDiffusion uses the pinned converted release at model revision `60ea7b6cc48d08487f95d06ba6ce59e15b619efd` and source revision `8ecd2d126d9f9e17b80d9655bf8ed2df2e93f660`. The saved component manifest identifies ControlNet, U-Net, VAE, text encoder, tokenizer, and scheduler files individually. An audit matched all 1,486 learned tensors between the original and converted checkpoints. [S36] [S37]

The demonstration pair is concatenated **input first, target second** along the channel dimension, giving six channels. The query condition has three channels. P1 uses 256×256 images. Selected candidate A1 normalizes all three permitted RGB images from `[0,255]` to `[0,1]`, then applies `2*x-1` once to every branch. The older converted-interface `[0,1]` recipe is a separate condition. The frozen task prompts use author-style labels for depth, HED edges, and semantic segmentation, plus the declared benchmark prompts for the other ten tasks. The negative text is empty. [S36] [S38]

## Sampler and arithmetic

The selected recipe uses BF16, a batch of four, DDIM 50, eta 0, guidance 7.5, and conditioning scale 1.0. Diffusion starts from CPU float32 Gaussian noise of shape `[4,32,32]` per query, then casts to the device dtype. The seed is the low 63 bits of the little-endian first eight SHA-256 bytes of the joined namespace, manifest hash, pack ID, and query record. Thus model noise is separate from episode seed 42 and is bound to record identity. [S36]

The engine concatenates negative and positive text embeddings, duplicates pair/query conditions for guidance, and evaluates ControlNet residuals followed by the U-Net. It combines epsilon predictions as `eps_uncond + 7.5*(eps_cond-eps_uncond)`. Each DDIM step computes the predicted clean latent from the current cumulative alpha and then the previous-step latent using the previous alpha; no extra noise is injected because eta is zero. Schedule coefficients are derived from the pinned scheduler. The implementation rejects incompatible prediction types, clipping, thresholding, or nonunit initial noise sigma. [S39]

The selected A1 full-test route has `cache_conditioning=False` and `dynamic_coefficients=False`. The module also implements conditioning caching and device-scalar schedules for other candidates; their presence does not mean A1 used them. Final latents are divided by the VAE's configured scaling factor, decoded, transformed by `decoded/2+0.5`, clipped, multiplied by 255, **rounded**, and converted to `uint8`. [S39]

## Device execution and verification

The full test runs on eight TPU devices with a `(4,2)` data/replica mesh. A partial batch duplicates the last real query; only real rows are saved. Every decoded batch is checked for finite values before quantization. The admission gate compares 16 representative predictions, requires finite raw batches, and repeats warm execution three times with identical pixels. All 221 frozen validation input bindings are replayed. The test receipt verifies 17,511 queries. [S40] [S04]

Four CPU float32 original-versus-converted comparisons, two fixtures under each input range, passed all 50 steps and decoding. Maximum raw decoded difference was about `7.1e-5`; common-rounding pixel MAE was below `0.00031` on the 0–255 scale. The released paths' truncation versus rounding remains separately recorded. This establishes the checked CPU conversion behavior, not a universal benefit of the A1 range or CUDA/TPU equivalence. The full paired range experiment improved six category means and worsened seven. [S21]

# RelationAdapter

## Backbone, relation path, and weights

The selected condition uses FLUX.1-dev revision `3de623fc3c33e44ffbe2bad470d0f45bccf2eb21`, RelationAdapter revision `7f65ecd6c7718c6de92782dade849a4872aa986a`, and SigLIP revision `9fdffc58afc957d1a03a25b10dba0329ab15c2a3`. The archived source commit is `0ebdebcf5697f5881b5bf3d2fd58d2938733a4e7`. Both `ip_adapter-100000.bin` and `pytorch_lora_weights.safetensors` are required. The LoRA is loaded, fused once, and its loading wrapper unloaded. Projection and attention-adapter weights are separately matched against the checkpoint. [S41] [S42]

The demo input and demo target are independently processed through the released resize and SigLIP image processor. SigLIP pooled outputs pass through the learned projection. The two projected representations are concatenated in source-then-target order. The projection and attention processors are constructed with 128 relation tokens. The query enters through the FLUX pipeline's `condition_image` VAE path. The FLUX stack has 19 dual-stream and 38 single-stream blocks; the repaired wrapping loader verifies that all 57 official block objects, plus the root, receive the intended SPMD/FSDP wrappers. [S42] [S43]

## Selected recipe

The selected P1 validation plan explicitly uses **“Apply the demonstrated image transformation.”** as neutral text, labeled a benchmark adaptation. It does not use the later task-directional instruction experiment. Text and pooled embeddings are prepared through the FLUX text encoders with maximum sequence length 512 and reused. Execution uses BF16, 24 FlowMatch Euler steps, guidance 3.5, relation alpha 1.0, and model seed 1000. The native benchmark call requests height and width 256 and one output. Final `[0,1]` pixels are multiplied by 255, rounded, and cast to RGB `uint8`. [S41] [S43]

The archived validation backend is a v5p-16, two-worker, eight-global-device, four-addressable-device-per-worker SPMD/FSDP port. Later replacement bundles have distinct topology contracts. Some later README prose contains contradictory worker/device labels; a rerun must use its executable topology checks and admitted backend receipt instead of copying those prose labels. No replacement topology is assumed to reproduce previous pixels automatically.

## Recovery candidates and coverage

The recovery implementation separates C0 from a C1 relation-key/value cache. The cache identity binds weights, official source, adapter source, runtime/environment, prompts, device precision, demo/query pixels, and seed. The cache is scoped to the specific prepared relation and is removed afterward. Directional `task_text_alpha1` conditioning is also a separate experiment from the neutral selected plan. These are not free changes to an archived row. [S42] [S44]

The selected 221-query validation archive is complete. A one-query text comparison is not a complete replacement recipe. A CPU BF16 full comparison stopped after two finite steps because measured runtime exceeded its cap; it does not establish full-sampler parity. The latest inspected audit lacks a terminal full-test receipt. The document therefore records the actual archived model and the prepared recovery changes separately. [S21] [S14]

# InstaManip

## Components and shot-specific checkpoints

InstaManip uses released `InstaManip-17B-1shot`, `2shot`, and `3shot` weights at revision `c63e249238beba8cc09342782a63322f0833d282`; source commit `be992025e226211352cbb6c0734f5243fe1972c4` is a separate identifier. The selected recipe is **P3 with the 3shot checkpoint**. Its asset manifest also pins SEED-X revision `534d2ff6669f36e4241a3d3fbbfa2d40adc04cdf`, Qwen-VL revision `f57cfbd358cb56b710d963669ad1bcfb44cdcdd8`, and SDXL revision `462165984030d82259a11f4367a4eed129e94a7b`. The selected P3 manifest hash is `32ce1fb1f79086bb0cccc5eb6da50a0e843197ce836690db961ffe13ca487ea5`. [S45] [S46]

The execution chain is visual encoder → multimodal agent with exemplar and edit-token conditioning → image-feature resampler → image-conditioned SDXL diffusion. It uses 64 tokens per image representation and 30 edit tokens. The prompt has seven image placeholders for P3, enclosed by `<img>` and `</img>`, plus an edit block. It is wrapped in `[INST] … [/INST]`, and the tokenizer's BOS is explicitly prepended. Greedy generation uses one beam and a token cap `450+100*P`, hence 750 for P3. Only the first generated image feature/output is used. [S47]

## Image preprocessing, image order, and attention scope

Demonstration inputs and targets visit Pillow's implicit 1024×1024 resize before the official 448-pixel CLIP transform. Query visual encoding goes directly from its 256-pixel RGB tile to the 448 transform. The query separately visits 1024×1024 for the SDXL image input. This demo-only intermediate resize is part of the released evaluator path, not an accidental redundant resize. [S47]

The visual batch groups all demonstration source images, all demonstration target images, and then the query. The agent receives these as named `exemplar_source`, `exemplar_target`, and `new` embeddings, matching the serialized prompt's source/target slots. A comparison mask marks image-token spans; a target mask marks exemplar-target spans. The lower-triangular scope mask is additionally restricted after the edit segment so later tokens cannot directly attend to the earlier exemplar span through the masked route. The exact mask and embedding order are preserved in the source bundle. [S47]

## Diffusion, seeds, and TPU implementation

The selected run uses 50 Euler diffusion steps, text guidance 7.5, image guidance 1.5, BF16, and native 1024×1024 output. Its per-episode noise seed is the low 63 bits of the little-endian first eight SHA-256 bytes of `42|task|q|P`. CPU float32 Gaussian noise has shape `[1,4,128,128]`; its bytes are hashed before casting to BF16. The pipeline receives this latent explicitly. This differs from the released evaluator's reset-to-42-per-call policy. [S45] [S47]

The port uses fixed-capacity per-layer KV storage and fuses the processor-forced image-token sequence into a causally masked block, retaining the official 64-token hidden span. It passes timestep/sigma scalars as device data through a versioned Euler adapter to avoid repeated compilation and preserves legacy callback order. A VAE boundary adapter casts the upstream forced-float32 image tensor to the pinned BF16 VAE dtype. These changes are part of the port identity, not new checkpoint training. [S47]

The **executed P3 backend is 32 devices across eight workers**, four addressable devices per worker. The defaults file contains stale 16-device/four-worker fields and a function docstring still says “16-way”; the recovered archive explicitly resolves that inconsistency in favor of the executed backend and qualification. The current runner derives its diffusion batch size from 32 global devices. The agent remains batch-one and sharded, while SDXL weights are replicated and the batch axis is sharded. Batches contain one task; a final short batch duplicates its last query, and padding outputs are discarded. The 1024 RGB prediction is saved and bicubic-resized to 256 for scoring. [S08] [S47]

## Validation and limitations

P1, P2, and P3 have complete 221-query validation archives. The P3 recovery verified 663 image artifacts. It improved nine task means and worsened four relative to P2, but checkpoint, demonstrations, seed material, hardware, and 66 targets differed. Two-shot CPU token and two complete 50-step diffusion fixtures passed their checked comparisons; this does not certify three-shot TPU BF16, all padded batches, or CUDA equality. The latest inspected full-test completion audit is incomplete. [S08] [S21] [S14]

# IMProv

## Model and visual layout

IMProv uses `IMProv-v1-0` revision `bc9d733ae2fc403600f87f8374b2eb544e6bd6dd` and matching VQ revision `f61ca369a6ac0fc3f45f335395320dee65b5a296`. The loader instantiates `PatchEmbedEncoder`, `TransformerMAE`, `VQDecoder`, and `MAEScheduler` from their saved component configurations and strictly loads their safetensors. Its text conditioner is a CLIP text encoder/tokenizer, producing an embedding of shape `[1,77,1024]`. The selected text is the empty string: this is the visual-only condition. [S48] [S21]

P1 uses a 224×224 white canvas with 111×111 tiles and a two-pixel internal gap. Demo input is top-left, demo target top-right, query bottom-left, and the missing output bottom-right. Tile resizing is bicubic. The bottom-right input is zero and has a one-valued mask; other mask pixels are zero. The image encoder uses ImageNet normalization, while the VQ decoder uses the release's 0.5 mean/std convention. [S48]

## One-step masked prediction

The full canvas becomes 14×14 = 196 patches with width 1,024. The mask is bilinearly resized to 14×14 and thresholded at `>0`; sorting its flattened values yields visible-token indices and restore indices. The masked canvas is encoded, visible embeddings are gathered, and the masked transformer predicts token logits conditioned on the empty-text embedding. The selected recipe has one inference step, guidance 1, and temperature 0, implemented as argmax over the predicted token logits. [S48]

The complete 14×14 code grid is decoded before any spatial extraction. The decoded missing region is composited with the original visible canvas. Full-grid floats are clipped to `[0,1]`, multiplied by 255, truncated to `uint8`, converted to PIL, cropped to the 111-pixel bottom-right tile, and bicubic-resized to 256. A previously attempted cropped VQ decode failed the device equality check and is not part of the selected path. [S48] [S21]

## Selected CPU recipe and edge postprocessing

The selected full test is CPU float32 with batch four, running on the selected TPU VM host CPU. Its qualification compares the archived forward to the released one-step pipeline on 16 inputs covering all 13 tasks, with exact image tokens, raw decoding, and final pixels. The broader saved CPU comparison also reports agreement between adapter and released pipeline on all 221 validation inputs. The complete test receipt verifies 17,511 queries. [S49] [S04] [S21]

The selected recipe adds a fixed **edge-only** postprocessor. Convert RGB to `[0,1]`, compute luma `0.299*R+0.587*G+0.114*B`, then use `sqrt(clamp(luma,0,1))` as confidence for the unchanged 99-threshold edge scorer. Other task predictions and copy controls are unchanged. This is a validation-selected contrast experiment, not a native decoder correction. Because the threshold grid is finite, a monotonic contrast mapping can change the reported best threshold score. [S50] [S09]

Older TPU and CPU-without-edge-contrast recipes remain separate. The small native output tile and VQ codec limit fine detail; interpolating it to 256 does not make it a native 256-pixel prediction. Codec round-trip diagnostics are not a mathematical upper bound on generated output quality. Empty text must not be presented as IMProv's complete image-plus-text method. [S21]

# Analogist

## Model, grid, and attention modifications

Analogist uses official source `3d7b485691ff50090af55caffb4bc7802990e5ca` with the `stable-diffusion-v1-5/stable-diffusion-inpainting` mirror at `8a4288a76071f7280aedbdb3253bdb9e9d5d84bb`. It combines the release's inpainting U-Net/VAE/scheduler with self-attention control and cross-attention masking. SAC scale is 1.3; SAC and CAM select layers `[3,11)`, i.e. layers 3 through 10. Editor counters reset for each inference call. [S51] [S52]

The image is a white 512×512 canvas. RGB demonstration input, demonstration output, and query are implicitly Pillow-resized to 253×253 and pasted at `(2,2)`, `(257,2)`, and `(2,257)`. The lower-left 256×256 quadrant is then copied to the lower-right quadrant. The pinned bottom-right inpainting mask defines the missing answer region. Thus the starting answer quadrant contains the copied query, not the target. Conditioning is normalized to `[-1,1]`; latent resolution is 64×64. [S52]

## Caption policy and candidates

The selected run freezes a current-vision caption cache built from permitted images, explicitly recording `uses_query_target=False` and `exact_official_prompt_route=False`. It is not the original paper's GPT-4V route. Each raw B-prime caption is one to five words; the full conditioned prompt, per-episode embedding, ordering, cache identity, and hashes are pinned. Positive validation embeddings have shape `[221,77,768]` and the negative embedding `[1,77,768]`. [S51] [S53]

The negative prompt is `Messy,Disordered,Chaotic,Cluttered,Haphazard,Unkempt,Scattered,Disheveled,Tangled,Random`. There are **eight independently retained candidates for one P1 episode**. Each candidate is scored separately; the episode score is the arithmetic mean of its eight candidate scores. There is no best-of-eight target selection and no pixel average. The older base plan still contains a one-output neutral-prompt adapter description; the selected current-vision execution wrapper and its bound prompt receipts override those historical execution fields while retaining the episode plan. [S51] [S53]

## Sampling and archived numerical behavior

Nominal DDIM steps are 50. Strength is 0.7 for denoising/deblurring, producing 35 executed steps, and 0.98 otherwise, producing 49. Guidance is 7.5 for inpainting and 15.0 otherwise. The selected archived wrapper executes BF16 in an eight-candidate batch over eight devices on two workers. It uses CPU float32 Gaussian draws before device casting. Seeds hash `analogist_official_q3_v1|episode_id|candidate=c|domain`, retaining the low 63 bits; domains are `diffusion`, `init_vae`, and `masked_vae`. [S51]

Crucially, that archived wrapper draws **candidate-specific initial-image and masked-image VAE posterior noises**, as well as diffusion noise. Later recovery notes propose restoring the release's sharing of each conditioning posterior draw across candidates and exact tensor DDIM arithmetic. Those are separately qualified correction candidates; they are not what the archived eight-candidate wrapper did. The older scalar update computes alphas on CPU and applies their square-root coefficients in the device sampling loop. [S51] [S52] [S21]

The starting latent combines the encoded copied-query grid with candidate diffusion noise at the selected starting alpha. Each U-Net step consumes noisy latent channels, the mask, and masked-image latents, with conditional/unconditional text duplication and CFG. After full VAE decode, values are mapped into `[0,1]`; the lower-right `[256:,256:]` quadrant is extracted, rounded to RGB `uint8`, and saved as a separate candidate PNG. The extracted output is 256×256, including the grid's border placement. [S51]

## Coverage

The validation archive contains 221 episodes × 8 = 1,768 candidates and corresponding averaged scores. Later model-repair qualifications and test caption preparation do not constitute completed test inference. The latest remaining-four audit has no Analogist terminal test receipt and retains the requirement of 140,088 candidate predictions. Historical checkpoint-byte and caption-route provenance limitations are retained. [S20] [S21] [S14]

# LVM 7B

## Autoregressive model and image codec

LVM uses the released 7B checkpoint revision `aa5a9039273bd4221a0f69f5c943de1c56c39d89` and improved VQ revision `e4b5f5f83d9588ed52b6d1b65b91262f9f2d804b`. The official source commit is `b6de939ef0eb1ee6593445a7f5268145f338749b`. The converted EasyLM checkpoint SHA-256 is `a5dfb7210a7a8a1a52492f0bf3b45010ec1da66dd5b2c5fd8245d7359f2ba0eb`; VQ weights have SHA-256 `fed960b9b88968dcaab28fd0cb28b786693b83b21fa93b1a1ad1177b3f7e9fd1`. The historical conversion audit reports an exact inverse round-trip for 291 tensors and 6,544,199,680 parameters. [S54] [S06]

The `vqlm_7b` config uses vocabulary size 8,292, hidden width 4,096, intermediate width 11,008, 32 layers, 32 heads, maximum sequence length 4,096, RMSNorm epsilon `1e-6`, and a KV cache. The vocabulary contains 8,192 image codes plus 100 special positions. The improved VQ codec encodes each 256×256 RGB image into 256 discrete tokens. VQ inference runs on CPU in the native runner; the causal model runs through JAX/Flax/EasyLM on TPU. [S55] [S54]

## Sequence assembly and sampling

P1 forms three frames, `demo input, demo target, query input`, totaling 768 context tokens; the next 256 tokens are the answer. Frames are normalized to `[0,1]` for the released codec and tokenized independently, then concatenated. No BOS token is inserted into the visual sequence. P2 uses 1,280 context plus 256 answer tokens; P4 uses 2,304 plus 256; P7 uses 3,840 plus 256, exactly the model's 4,096-token limit. [S54] [S56]

The selected generation uses temperature 1.0, top-p 0.9, top-k 50, seed 0, one beam, and one candidate. It must produce exactly 256 image codes in `[0,8191]`. Logits at indices 8192 and above are suppressed. **Code 2 is a valid visual token**, so inheriting a text-model EOS of 2 would stop a generated image early. The native runner sets both EOS and padding to suppressed ID 8192, making EOS unreachable. The generated code range and length are checked before VQ decoding. [S54] [S56]

## TPU and runtime adaptations

Model parameters and activations use FP16. The model is instantiated without random initialization, the converted parameters are loaded on CPU, and EasyLM partition rules create shard/gather functions. The mesh is `1,device_count,1`, and `pjit` wraps generation. For selected P1, scan-attention query/key chunks are 1,024, covering the full prompt-plus-answer extent, and scan-MLP is disabled for cached single-token decoding. The released 4,096-token maximum remains unchanged; these are execution-shape adaptations, not learned weight edits. [S54] [S56]

The September path first attempted the old JAX 0.4.13 runtime, which failed TPU initialization before model execution. The host-compatible JAX 0.6.2 path then verified devices and a 1,536-token attention chunk for the older P2 run against dense attention, with maximum absolute difference `2.384e-7`. Those historical P2 chunk settings must not be copied over the later P1 config. [S06]

## Variants and completion

Native P1/P2/P4 validation recipes are complete. An older P7 row is explicitly diagnostic because of its legacy plan; preparing an authenticated P7 context does not turn that older row into a completed native P7 rerun. The selected P1 full test has a terminal receipt covering all 17,511 queries, including preserved outputs and recovered shards, with individual artifact hashes verified. Its receipt makes no cross-hardware pixel-parity claim. Codec diagnostics establish scale-dependent information loss, not that all weak generated normal or landmark predictions are caused by the codec. [S20] [S21] [S04]

# Exact text conditioning

Prompt strings are implementation inputs. A paraphrase is not equivalent for replay. Visual-only Painter, VICT, GenLV, and LVM have no task-text condition. LaVin-DiT's selected sequence is image-conditioned. IMProv uses empty text. RelationAdapter uses its neutral sentence, and Analogist uses its frozen per-query caption cache. The three task-prompt dictionaries below are copied verbatim from the selected saved sources. [S15] [S37] [S46]

## VisualCloze task prompts

| Task | Exact text |
| --- | --- |
| colorization | Each row shows the transformation from [IMAGE1] a grayscale photograph to [IMAGE2] a naturally colored photograph of the same scene. |
| deblurring | Each row shows the transformation from [IMAGE1] a blurred photograph to [IMAGE2] a sharp photograph of the same scene. |
| denoising | Each row shows the transformation from [IMAGE1] a noisy photograph to [IMAGE2] a clean photograph of the same scene. |
| edge_detection | Each row shows the transformation from [IMAGE1] a photograph to [IMAGE2] an edge map showing object and region boundaries. |
| face_landmarks | Each row shows the transformation from [IMAGE1] a face photograph to [IMAGE2] a facial-landmark point map using the examples' landmark and color convention. |
| human_pose_2d | Each row shows the transformation from [IMAGE1] a photograph of a person to [IMAGE2] a body-joint marker map using the examples' joint and color convention. |
| inpainting | Each row shows the transformation from [IMAGE1] a photograph with missing regions to [IMAGE2] a complete photograph with those regions filled consistently with the surrounding scene. |
| instance_segmentation | Each row shows the transformation from [IMAGE1] a photograph to [IMAGE2] an instance segmentation map with separate object regions using the examples' colors. |
| relative_depth | Each row shows the transformation from [IMAGE1] a photograph to [IMAGE2] a grayscale relative-depth map using the examples' depth direction and intensity convention. |
| saliency_detection | Each row shows the transformation from [IMAGE1] a photograph to [IMAGE2] a salient-foreground mask using the examples' foreground and background colors. |
| semantic_segmentation | Each row shows the transformation from [IMAGE1] a photograph to [IMAGE2] a semantic segmentation map using the examples' class colors. |
| super_resolution | Each row shows the transformation from [IMAGE1] a low-resolution photograph to [IMAGE2] a higher-resolution photograph of the same scene with faithful fine detail. |
| surface_normals | Each row shows the transformation from [IMAGE1] a photograph to [IMAGE2] an RGB surface-normal map using the examples' coordinate and color convention. |

## PromptDiffusion task prompts

| Task | Exact text |
| --- | --- |
| colorization | a naturally colored image |
| deblurring | a sharp image without blur |
| denoising | a clean image without noise |
| edge_detection | hed map |
| face_landmarks | facial landmark map |
| human_pose_2d | human pose skeleton map |
| inpainting | a complete image with missing regions filled |
| instance_segmentation | instance segmentation map |
| relative_depth | depth map |
| saliency_detection | saliency map |
| semantic_segmentation | segmentation map |
| super_resolution | a sharp, high-resolution image |
| surface_normals | surface normal map |

## InstaManip task instructions

| Task | Exact text |
| --- | --- |
| colorization | Colorize the grayscale image with realistic colors while preserving its exact content, structure, and lighting. |
| deblurring | Remove the blur and restore a sharp image without changing the scene, objects, colors, or composition. |
| denoising | Remove the image noise while preserving all real details, colors, edges, and scene content. |
| edge_detection | Convert the image into an edge map containing only white object and region boundaries on a black background. |
| face_landmarks | Locate the facial landmarks and output only the colored landmark points on a black background, following the exact point and color convention shown in the examples. |
| human_pose_2d | Locate the person’s 2D body joints and output only the colored joint markers on a black background, following the exact joint and color convention shown in the examples. |
| inpainting | Fill in the black missing regions with content consistent with the surrounding image, while leaving every unmasked pixel unchanged. |
| instance_segmentation | Segment every individual object instance and output only a flat color mask, using one solid color per instance and the exact color convention shown in the examples. |
| relative_depth | Predict a dense relative-depth map for the entire image, following the exact grayscale depth direction and intensity convention shown in the examples. |
| saliency_detection | Identify the most visually salient foreground object and output a binary mask with the salient region in white and the background in black. |
| semantic_segmentation | Assign every pixel its semantic class and output only a flat color segmentation mask, using the exact class-color convention shown in the examples with no photographic texture or shading. |
| super_resolution | Restore a high-resolution version of the image with faithful fine detail while preserving the exact objects, geometry, identity, colors, and composition. |
| surface_normals | Predict a dense per-pixel surface-normal map encoded as RGB colors, following the exact coordinate and color convention shown in the examples without retaining photographic texture. |

# Reproducibility and run interpretation

## What constitutes the same implementation

A reproducible row binds more than a model name: checkpoint bytes and conversion, source revision, exact episode plan and palette convention, model-noise generation, prompt bytes/tokenization, preprocessing order, input resolution, dtype, sampler arithmetic, output interpolation/quantization, batch padding, hardware topology, and scorer identity. Changes to any of these need an explicit version boundary or an equality qualification at the relevant scope.

Backend repetition proves repetition on the checked backend. CPU reference parity proves the checked CPU operations. An exact checkpoint conversion proves tensor identity under the recorded mapping. None alone proves CUDA/TPU activation parity. A model can pass finite-output checks and still perform poorly; a PNG file can exist even after nonfinite floats were converted, which is why the later raw-output checks matter.

The six complete test receipts are stronger evidence than stale website status text. Conversely, a preparation JSON, a launch command, an `INFERENCE_COMPLETE` marker without score coverage, or a successful first batch is not enough to claim a scored full-test result. Records with “awaiting authorization” are historical execution text; they are not new permission requirements introduced by this documentation task.

## Concrete reproduction sequence

1. Select the model **and recipe**, including archived versus corrected execution, P, prompt policy, and any selected scorer amendments.
2. Use the preserved plan and source hashes to authenticate the episode builder and all pack files. Stage the pack and model assets in the execution region and verify the full asset set.
3. Restore that recipe's pinned environment. Check version receipts and compatibility adapters; do not replace them with an unconstrained latest package installation.
4. Replay the frozen permitted inputs and compare record order, convention IDs, and pixel hashes. Preserve padding rules without counting padding as data.
5. Run the corresponding qualification on the chosen backend. For stateful VICT, preserve ordered random-state history; for candidate-based Analogist, retain every candidate and its separate random domains.
6. Generate raw and scoring-resolution outputs with the exact conversion order. Save source, runtime, input, prompt, noise, and output identities; reject nonfinite raw values before converting to pixels.
7. Score with the frozen metric release plus the recipe's declared amendments and original sidecars. Keep copy controls, per-query values, and candidate aggregation separate from model inference.
8. Require exact expected query/candidate counts, complete scored packs, and artifact hashes before issuing a terminal completion receipt.

This is the reproduction order, not a runnable blanket launch command. Many archived scripts intentionally contain exact hostnames, elapsed-deadline gates, old cache paths, and historical topology assertions. Reusing them requires a separately identified launch wrapper while preserving their numerical implementation. No evaluation or machine acquisition was needed to prepare this reference.

## Software environments

There is no single environment for all eleven models. Painter and the recorded CPU GenLV/IMProv qualifications use Torch 2.7.0+cpu; Painter's TPU qualification adds Torch-XLA 2.7.0. The selected PromptDiffusion gate binds the complete installed-package and XLA-flag identity. RelationAdapter's recovered runtime lock pins Torch/Torch-XLA 2.8.0, torchvision 0.23.0+cpu, Diffusers 0.32.2, Transformers 4.44.0, and NumPy 1.26.4. LaVin's component lock pins, among others, Diffusers 0.29.0, torchdiffeq 0.2.4, timm 0.9.12, Pillow 10.2.0, and NumPy 1.26.4; the launch/backend receipt supplies its Torch/XLA environment. [S25] [S31] [S49] [S57] [S58]

VisualCloze uses custom pinned pipeline source in addition to installed package metadata. Its selected runtime verification enumerates the exact installed source hashes; package version strings alone are insufficient. LVM has JAX/Flax/EasyLM-specific compatibility files and a separate CPU VQ dependency chain. The source bundle includes the inspected lock/identity records rather than claiming a synthesized environment was executed. [S16] [S54]

## Important version boundaries

| Boundary | Interpretation that preserves the implementation |
|---|---|
| v5 versus Bench v2 v6 | Different packs, task counts, targets, and evaluation contracts. |
| VisualCloze archived versus FP32-norm repair | Same selected weights and conditioning; changed arithmetic and changed archived pixels. |
| Painter and VICT depth decoding | Saved-prediction output interpretation; separate from metadata-assisted native adapters. |
| VICT R0 versus boundary-corrected CPU fixtures | Different output execution boundaries; parity fixtures do not silently replace archived R0. |
| GenLV and IMProv CPU versus archived TPU | Separate numerical execution recipes, even with the same weights. |
| LaVin reset-per-draw versus advancing RNG | Different random-stream contracts; the latter is a proposed/recovery condition. |
| PromptDiffusion A1 versus original converted-interface range | Explicit `[-1,1]` versus `[0,1]` input conditions. |
| RelationAdapter neutral versus task-directional text | Separate prompt conditions; the selected full validation is neutral. |
| InstaManip P1/P2/P3 | Shot-specific checkpoints and episode/noise changes, plus topology and palette differences. |
| IMProv edge square root | Validation-selected postprocessing experiment, not native codec decoding. |
| Analogist archived candidate VAE draws versus shared-draw repair | Different candidate conditioning-noise contracts. |
| LVM P1/P2/P4 versus legacy P7 | Native authenticated recipes versus explicitly diagnostic legacy-plan measurement. |
| Signed-scale depth versus nonnegative-scale depth | Different evaluation protocols; signed alignment uses target information at scoring time. |

# Test pack inventory

| Task | Dataset pack | Queries | Pack identity |
| --- | --- | --- | --- |
| colorization | ade20k_val | 2000 | 2e4aee014865e43805de82be3fc7aec27138e461 |
| colorization | div2k_val | 100 | 298cc93c3bfdb2e877187d83b019fa5fb0a9e337 |
| deblurring | gopro_test | 1111 | 1e1d98bc7a9da5d31edd41fda9f68dbf50da36ca |
| deblurring | realblur_j_test | 980 | a703a3c23ca0c26ed39585b3c6f44b89e462e32f |
| denoising | cbsd68 | 68 | bf2cceac817ed29f98b0f7b82285bafc02423331 |
| denoising | sidd_val | 1280 | 5f86b2a7ede5aaa55c237191baaa5cc77908edbf |
| edge_detection | bsds500_test | 200 | 109c50e6bec431f863a6fed5386768b809c0ed69 |
| edge_detection | nyudv2_test_hed | 654 | 0ff737ffde8393a9759bee554c21e5a6192bb186 |
| face_landmarks | 300w_test | 600 | c07f3101c62650ab225fb245002a6b7833bfc54c |
| face_landmarks | cofw68_test | 507 | 725d42dbd7043fb19ce8d896d37fa2531c8729a5 |
| human_pose_2d | flic_test | 926 | 8cf3b0a3527c3bd489f1aba03991b479f69be2d1 |
| human_pose_2d | lsp_test | 1000 | 976c15c8df30a1039f3d9c3b4047dac93466a62f |
| inpainting | div2k_val | 100 | b839bcf9a19f365d06f4c347566443d92b2d76d2 |
| inpainting | urban100 | 100 | 16d419ca5602bd098774e20b2f0a9ecd2a5aef73 |
| instance_segmentation | nyuv2_test | 654 | c3a2c6d6087a4e5bc9d688345d30d1c5013a9d33 |
| instance_segmentation | voc2012_val | 1449 | 47dac2576ba6cb5d19412f87fc43519d5cc6b7b6 |
| relative_depth | diode_val | 771 | d77bf9878ce60aaaaf66d6db7656a5b51bfc10e5 |
| relative_depth | nyuv2_test | 654 | 9512cf3953e33e8c6c8b918e83b17f06dbeca907 |
| saliency_detection | ecssd | 1000 | be2e8c72180e24f13d59aad65e568b0da8d4fcd2 |
| saliency_detection | pascal_s | 845 | 0aab28260e30db65c01b5de2d3e589c1a98e43dd |
| semantic_segmentation | camvid_test | 233 | 7ee8f56a1e15e40a08ee59804ce79392f5f87fbf |
| semantic_segmentation | nyuv2_test_40 | 654 | d0514b884e4f7f89e8081918919dbae13b5073d3 |
| super_resolution | div2k_val | 100 | c96a67c01870e16c67bad0b729c9bfdce76082bc |
| super_resolution | urban100 | 100 | 9de38437da6fb4110d5f2414f42325ec0c6bdff2 |
| surface_normals | diode_val | 771 | 4b27e37daaee75b4c900c9b33f02bf67f455fde0 |
| surface_normals | nyuv2_test_geonet | 654 | 9ae28e5196b35f64743b230a5019017389205a8f |

# Archived variant inventory

The following table is extracted from the saved demonstration-count comparison, with recovered InstaManip P3 listed separately above. Each row in that comparison contains 221 queries. Other CPU-reference, task-adapter, postprocessing, and recovery variants are described in the corresponding model section; a proposed candidate with no completed archive is not counted as an evaluated variant.

| Recipe | P | Saved status |
| --- | --- | --- |
| visualcloze-p1 | 1 | complete authoritative corrected-v3 validation |
| painter-p1 | 1 | PASS phase-gated validation |
| vict-p1 | 1 | authoritative corrected-v3 validation complete |
| genlv-p1 | 1 | PASS phase-gated validation |
| lavin-dit-p1 | 1 | complete corrected validation |
| prompt-diffusion-p1 | 1 | authoritative corrected-v3 validation complete |
| relation-adapter-p1 | 1 | authoritative corrected-v3 validation complete |
| instamanip-p1 | 1 | complete corrected validation |
| improv-p1 | 1 | authoritative corrected-v3 validation complete |
| analogist-p1 | 1 | authoritative corrected-v3 validation complete · 8-candidate mean |
| lvm-p1 | 1 | complete corrected validation |
| visualcloze-p2 | 2 | complete authoritative corrected-v3 validation |
| lavin-dit-p2 | 2 | complete corrected validation |
| instamanip-p2 | 2 | complete corrected validation |
| lvm-p2 | 2 | complete corrected validation |
| visualcloze-p4 | 4 | complete authoritative corrected-v3 validation |
| lavin-dit-p4 | 4 | complete corrected validation |
| lvm-p4 | 4 | complete corrected validation |
| visualcloze-p8 | 8 | complete authoritative corrected-v3 validation |
| lavin-dit-p8 | 8 | complete corrected validation |
| lvm-p7 | 7 | diagnostic legacy-plan snapshot · not a phase gate |

# Source index and exact implementation bundle

The source bundle preserves the inspected files with an index mapping source IDs to original absolute paths, archive paths, sizes, and SHA-256 hashes. It contains selected inference code, frozen plans/configurations, exact prompts, correction implementations, environment records, and run receipts. It does not contain model weight binaries or benchmark image packs. Full model assets are identified by their original manifests and hashes. A recovered working source can contain later changes while its frozen plan still records the earlier source hash; the bundle records the bytes inspected here and does not assert that every recovered file equals every historical plan hash.

Paths below point to the shared workspace. Copies in the companion bundle keep this reference usable if a working file changes later. Source IDs attached to a section identify implementation evidence, not an endorsement of every historical status or proposed action written in that file.

**S01** — [best-results.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/dist/10-12-validations/best-results.json). SHA-256 `4be74166bf746668f0d6ec01d3726a13d27a80dd006f6ccbf2e39fc97bae7a4b`.

**S02** — [all11_test_configuration_audit.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/all11_test_configuration_audit.json). SHA-256 `57b0319a63614fe7976d1d89a950e10aedc3a95e7f9beca09aa90a8425a1e612`.

**S03** — [campaign.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/campaign.json). SHA-256 `0da3014e53bb861867614770970e40bd3b6dd36c7138b8fbbc86ec6bccb85bfe`.

**S04** — [verified_test_receipts.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/reports/baseline_implementations_2026-11-19/verified_test_receipts.json). SHA-256 `85ffaf3d8e3feb5a29fd796c1854752af7d29dbbf531a16b26cca3a35101ff2d`.

**S05** — [AGENTS.md](/kmh-nfs-ssd-us-mount/code/kristine/lvm/AGENTS.md). SHA-256 `8d3bab4144c2b86793b066db0e651cba7ba0fc2dd638f6c74de021fb0c123a56`.

**S06** — [visualcloze-open-model-tpu-evals.md](/kmh-nfs-ssd-us-mount/code/kristine/lvm/experiment_log/2026-09-26/visualcloze-open-model-tpu-evals.md). SHA-256 `103ad68772476f9a2bb179efe39b2d0d6d9ee630f8729e331ca962bd95717927`.

**S07** — [bench_episode_v1.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/runner/tools/bench_episode_v1.py). SHA-256 `efc614de568df9eaa907f5d946a257a8f1f7ef915d47e604d10f671b13e8d81b`.

**S08** — [data.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/dist/bench-v2-instamanip-p3/data.json). SHA-256 `5edb4c0a37cd5f193f0dc24e097e12d30df921be4e11a894c099ca6539e516e6`.

**S09** — [selected_metric_backend.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/selected_metric_backend.py). SHA-256 `6f0fea22ddb0756bce67c1ae611aada9a7170e461d1aee26274433a1879fa37f`.

**S10** — [protocol_v1.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/visualcloze_recovery/source/scorer_snapshot/jflux2/fasteval/eval_v2/protocol_v1.py). SHA-256 `2d8a72034245d9e6f95a8ce98c342cddaa96ac8b6b85d411ef2ae7a551f2b910`.

**S11** — [postprocess_v2.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/visualcloze_recovery/source/scorer_snapshot/jflux2/fasteval/eval_v2/postprocess_v2.py). SHA-256 `7ca4bb39c4850d3c9620d8e5a131271b063291083ee2cfc40b398bcd20cc2098`.

**S12** — [vict-edge-aggregation-correction.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/dist/data/vict-edge-aggregation-correction.json). SHA-256 `00f16b877438579d2d7495c25b16b046742b597c9330b4410aa1695fbd59b23f`.

**S13** — [signed_depth_metric.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/dist/bench-v2-signed-depth/signed_depth_metric.py). SHA-256 `0dda801d349f87ec2a09b09b818c98917372e3687a6849cb3250d7e3ff92c4b9`.

**S14** — [remaining_four_completion_audit.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovery_20261113/remaining_four_completion_audit.json). SHA-256 `ebfd7fb2dca6c4e5684ecda2d1e39dd0546b6e23c9486c981025495888863ff9`.

**S15** — [visualcloze_p2_task_text.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/visualcloze_recovery/source/baseline/p2/visualcloze_p2_task_text.py). SHA-256 `5b13ab08885d48b20cf91c457f6ff8f960e788238bfb24a05106a95613162912`.

**S16** — [visualcloze_runtime_source_verification.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/visualcloze_runtime_source_verification.json). SHA-256 `dd2ca01b363ac83d55714fa9eb2b488a444fcff8694b1a0da76e2ea8ee8089d8`.

**S17** — [visualcloze_decode_failure_localization.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/visualcloze_decode_failure_localization.json). SHA-256 `54f9cc2ba3bc453f8e7643697b2f076539ac6a61bcdf76c1cfcdac3d3ba4ed87`.

**S18** — [run_visualcloze_tests.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/run_visualcloze_tests.py). SHA-256 `1d03b3c22e1ef82c80474d297873bb2dd5e69c8e87f8cc11b8cbaa960686dac2`.

**S19** — [visualcloze_diagnostic9_qualification_decision.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/visualcloze_diagnostic9_qualification_decision.json). SHA-256 `3e1f3319e7b7245283c0a7daf521172103384193df07cc15942310df712dff27`.

**S20** — [bench-v2-validation-demo-counts.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/dist/data/bench-v2-validation-demo-counts.json). SHA-256 `b918c5c27de5a6b22bf88fb8a0791ce0558f560ffa7bfa5c9654febcce4842c8`.

**S21** — [data.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/dist/bench-v2-review/data.json). SHA-256 `132a2440d941440255882052e51d5d205f7ea3ac0a9e5aec7d53a65bb38d953c`.

**S22** — [painter_native.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/painter_runner/painter_native.py). SHA-256 `bd9053a745bd957e808011b0b8003e26454855de78946899f79b2f88ba685dc6`.

**S23** — [models_painter.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/painter_runner/official/Painter/models_painter.py). SHA-256 `c9e9de03bab79cee287f4bf89e53b4c2221f018995c8e61e95c99bd449f94035`.

**S24** — [depth_output_adapter.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/scripts/depth_output_adapter.py). SHA-256 `b7283b8e45263fb6952fcbb0673d3578173f88db155c5329ff43f02d38398b8d`.

**S25** — [painter_qualification.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/painter_qualification.json). SHA-256 `68107c4589d0d34ef71178544a9ef49c9aaf00c8427267b44e7d609c48f5c329`.

**S26** — [vict_native.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/vict_runner/vict_native.py). SHA-256 `563bcecd89ca8a23084dc334f951a91210c729b2f9e3bfe5940117c5e79c2a93`.

**S27** — [adaptation.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/vict_runner/adaptation.py). SHA-256 `c65f46fb8c25835a985542a8f912ce628daf9c6f1596771a6da6f98ff82603f1`.

**S28** — [run_tests.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/vict_runner/run_tests.py). SHA-256 `9d480450a02655307e6c9b4ad5fc80be90e6f74a784e72d1fa4305a36c3ef1d9`.

**S29** — [genlv_runtime.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/runner/source/optimized/genlv_runtime.py). SHA-256 `641025a1c6a56f896b7a0fe809256bcf6b6ceed0a889a2b80f5e53923bbebebd`.

**S30** — [xrestormer_prompt_crossattn_wores.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/runner/source/official/extended_version/models/xrestormer_prompt_crossattn_wores.py). SHA-256 `335170a288a224b181b90b579d4321af749a4da7e3f1d8afc181f10cbbc29bac`.

**S31** — [genlv_test.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/runner/genlv_test.py). SHA-256 `73544bf8ebc121a81ad400d1e653aaffec21bb0a234d951e21c8c241d0dc1469`.

**S32** — [defaults.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/lavin_p8_retry18/defaults.json). SHA-256 `0688bcf2ea60d3007fbc3ee46438cb5316881e842f40ac4461df578e0adffd59`.

**S33** — [dit.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/lavin_p8_retry18/official/lib/model/dit.py). SHA-256 `b5bfd6b8a0e894b75d62125749dd7f2eebbfe7f13e7b5841d11e83442033122c`.

**S34** — [lavin_dit_bench_v2.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/lavin_p8_retry18/lavin_dit_bench_v2.py). SHA-256 `39e62db93bd36beb069fa41a1c8fca0fadbaf12d01b62d091b47e35e45f8ee15`.

**S35** — [ARCHIVED_COMPLETION_VERIFIED.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/lavin_p8_retry18/ARCHIVED_COMPLETION_VERIFIED.json). SHA-256 `baae797d71874013eedbdf53be86447ac2e0e4569e5726b79e84d991d2dba372`.

**S36** — [contracts.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/promptdiffusion_runner/source_optimized/contracts.py). SHA-256 `b729bb9ebcc266aa3d532a890244f35785cf660cae6b0b33250334d8cde4f00b`.

**S37** — [frozen_assets.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/promptdiffusion_runner/source_optimized/frozen_assets.json). SHA-256 `885caf4fa079060e1dc79efbf1aafbd585d03b17769f486844e4624a2719c205`.

**S38** — [promptdiffusion_recipe_binding_audit.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/promptdiffusion_recipe_binding_audit.json). SHA-256 `6a8042973c31ff6e99d52cff399f35747a8da0d0e82cfe11329495f901fad411`.

**S39** — [engine.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/promptdiffusion_runner/source_optimized/engine.py). SHA-256 `154cf342fbba84d1d8210dbd91f53a924604b906a32b199e7c757c143431c05b`.

**S40** — [run_tests_retry1.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/promptdiffusion_runner/run_tests_retry1.py). SHA-256 `55993b8e407efc1dbace521faf630891cf4359f26004aaebbe28ce9ea34eccb3`.

**S41** — [plan_val.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/relation/plan_val.json). SHA-256 `7f2dcd27982d561ed674ef95235879877a7840e11a5c047db1d7eb28efba3701`.

**S42** — [runtime_loader.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/relation/source/runtime_loader.py). SHA-256 `f8fd382cd1d03f501a969e17959653d516a772eefdf178aec6aac414ab2635a8`.

**S43** — [relation_adapter_bench_v2.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/relation/source/baseline_archive/relation_adapter_bench_v2.py). SHA-256 `c6a7b39db6a0aaf1e96f7846c0a20efe37fe889010d9ebde8c5f4b0dcf816be2`.

**S44** — [run_target_free.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/relation/source/run_target_free.py). SHA-256 `ccca018de54381b5e776fd4a212bebf1ad6a586b81cf1c84e094088d41104e26`.

**S45** — [defaults.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/instamanip_p3/defaults.json). SHA-256 `f8d552caf05a6d994416b69777d546359ac0811b65a5c091bea7a96bfdc405b8`.

**S46** — [validation_plan.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/instamanip_p3/validation_plan.json). SHA-256 `d120a5c6d8ad3658219a2aa3d4c5fb61b697ca6eee1baed56704a8a31fd7921e`.

**S47** — [instamanip_bench_v2.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/instamanip_p3/instamanip_bench_v2.py). SHA-256 `f20ccf0957b9f24533e705df4190caecfb0549ce6f35b3e816abb319471c4e71`.

**S48** — [improv_cpu.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/improv_runner/improv_cpu.py). SHA-256 `1e829bc16af6002e50e86fafa1423a9a075116bdb174c5772c96d10a009f01d8`.

**S49** — [improv_model_qualification.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/improv_model_qualification.json). SHA-256 `ae6be8c0e8a824cc86763a44561f9a2d5dd9bae4e673ffa44d72c1fea2901a80`.

**S50** — [edge_contrast_adapter.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/visualcloze-results-site/scripts/edge_contrast_adapter.py). SHA-256 `ca93b7ed369ada346c373949cb971afcbf67758a3c3af7346210ce48c77bb26c`.

**S51** — [analogist_q4_v5p16.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/analogist_selected/analogist_q4_v5p16.py). SHA-256 `8f80729fa26c87c4adab2104e9ccbe054df27377289a34676fcd66ec64a09453`.

**S52** — [q2_analogist_bench_v2.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/analogist_selected/q2_analogist_bench_v2.py). SHA-256 `b10095ab583417bc54e2d7ffb6ceff1d037f06bd15684834391ed79a9119aa25`.

**S53** — [CURRENT_VISION_PROMPT_CACHE_RECEIPT.json](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/analogist_selected/CURRENT_VISION_PROMPT_CACHE_RECEIPT.json). SHA-256 `68f6b23856250f96ee2ac8a27281eff1a7e2ef7b7ccebad2c71c4c07c639674a`.

**S54** — [lvm_bench_v2.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/lvm/lvm_bench_v2.py). SHA-256 `1926c1a1f2d196a4dfd4836b3b134ff05ad581535bd74714dd906c324dc7e854`.

**S55** — [llama_model.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/lvm_runner/official/EasyLM/models/llama/llama_model.py). SHA-256 `4250497679762193161e3d131b9716dacbf5da14cb13cb9d91e87eca49a5c19f`.

**S56** — [lvm_runtime_config.py](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/lvm/lvm_runtime_config.py). SHA-256 `bf96532fc7dbddc3f6033df0437c7dced058882e9c5cc547d8cb5c4e2690c7a8`.

**S57** — [full_runtime.lock](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/relation/source/full_runtime.lock). SHA-256 `ef10345c8229cc29e11d7c4bf2cdbe8ea94d5e3f3c26d49dc94e254da6c48ca6`.

**S58** — [requirements.runtime.lock](/kmh-nfs-ssd-us-mount/code/kristine/lvm/eval_runs/2026-11-10/bench_v2_all11_test/recovered/lavin_p8_retry18/requirements.runtime.lock). SHA-256 `1f09df03edc8030613494a0bf44a3de9557c64e3f914a65eceffee301ab24245`.
