"""Concrete phase commands for a fresh, full 221-episode validation trial.

Never prints examples or per-example scores. The remote staging session stays
alive across barriers and enforces an absolute 32-chip/1800-second limit.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time
from execution_contract import validate_qualification, require_authorized_resource

ROOT=Path(__file__).resolve().parents[1]
NAME='kmh-tpuvm-v5p-64-us-east5-spot-jaustin-aj4jza'
WORK=Path('/tmp/relationadapter_autoresearch_010427/scoring')
PYTHON='/kmh-nfs-ssd-us-mount/code/xtiange/anaconda3/envs/resnet/bin/python'
SHARED='/kmh-nfs-ssd-us-mount/code/xtiange/jflux2'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda:f.read(8<<20),b''): h.update(data)
    return h.hexdigest()


def put(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def wait_workers(trial,filename):
    deadline=json.loads((trial/'session.json').read_text())['deadline_epoch']
    admission=json.loads((trial/'before_staging_gate.json').read_text())
    workers=sorted(set(re.findall(r'^AVAILABLE worker=(\S+)',admission['occupancy_output'],re.MULTILINE)))
    if len(workers)!=8:raise RuntimeError('expected eight admitted workers')
    while time.time()<deadline:
        # Direct opens avoid stale NFS directory listings delaying a barrier.
        files=[]
        for worker in workers:
            path=trial/'workers'/worker/filename
            try:path.read_bytes()
            except FileNotFoundError:continue
            files.append(path)
        if len(files)==8:return files
        if filename!='session_exit_code':
            for worker in workers:
                try:(trial/'workers'/worker/'session_exit_code').read_bytes()
                except FileNotFoundError:continue
                raise RuntimeError('worker exited before complete phase coverage')
        time.sleep(2)
    raise TimeoutError('accelerator session deadline reached')


def fresh_gate(trial):
    path=trial/'before_inference_gate.json'
    subprocess.run(['python3','-B',str(ROOT/'source/prelaunch_gate.py'),'--name',NAME,'--zone','us-east5-a',
        '--inventory',str(ROOT/'receipts/non_kristine_search_0207/kristine_inventory.log'),
        '--inventory-receipt',str(ROOT/'receipts/non_kristine_search_0207/kristine_inventory_receipt.json'),
        '--assignment',str(ROOT/'receipts/shared_assignment.json'),'--out',str(path)],check=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--trial',required=True,choices=['validation_00'+str(i) for i in range(1,6)])
    parser.add_argument('--phase',required=True,choices=['staging','environment','input_export','inference','scoring_materialization','scoring','aggregation'])
    args=parser.parse_args()
    trial=ROOT/'trials'/args.trial
    selection=json.loads((trial/'selection.json').read_text())
    qualification=json.loads((trial/'qualification.json').read_text())
    assert sha(trial/'qualification.json')==selection['qualification_sha256']
    validate_qualification(qualification,candidate=selection['candidate'],tpu_name=NAME,runtime_identity=selection['runtime_identity'])
    require_authorized_resource(NAME)
    score=WORK/'corrected_v3_val'/args.trial
    unit=score/'units/bench_v2_val'
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',
             PYTHONPATH=str(ROOT/'source')+':'+str(ROOT/'source/baseline_archive')+':'+SHARED,
             RELATION_BENCH_WORK_ROOT=str(WORK),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    def run(argv):subprocess.run(argv,env=env,check=True)
    try:
        if args.phase=='staging':
            # Local CPU scoring assets are reused only after full hash checks;
            # this is explicitly a warm-asset trial, not a cold download claim.
            stage=json.loads((ROOT/'receipts/scoring_asset_stage.json').read_text())
            for item in stage['files']:
                assert sha(item['local'])==item['sha256']
            deadline=min(int(time.time())+1800,selection['accelerator_deadline_epoch'])
            remote='bash '+shlex.quote(str(ROOT/'source/validation_remote.sh'))+' '+args.trial+' '+str(deadline)
            argv=['gcloud','compute','tpus','tpu-vm','ssh',NAME,'--project=he-vision-group','--zone=us-east5-a',
                  '--worker=all','--internal-ip','--ssh-flag=-F','--ssh-flag=/dev/null','--command='+remote]
            with (trial/'transport.log').open('xb') as log:
                child=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            put(trial/'session.json',{'deadline_epoch':deadline,'transport_pid':child.pid,
                'remote_timeout_enforced':True,'workers':8,'physical_chips':32})
            files=wait_workers(trial,'setup_receipt.json')
            assert all(json.loads(p.read_text())['status']=='SETUP_COMPLETE_ASSETS_VERIFIED' for p in files)
        elif args.phase=='environment':
            (trial/'ENVIRONMENT_GO').write_text(str(time.time()))
            files=wait_workers(trial,'environment_receipt.json')
            assert all(json.loads(p.read_text())=={'status':'VERIFIED','runtime_identity':selection['runtime_identity'],
                'compilation_cache_condition':selection['compilation_cache_condition']} for p in files)
        elif args.phase=='input_export':
            (trial/'INPUT_EXPORT_GO').write_text(str(time.time()))
            files=wait_workers(trial,'input_export_receipt.json')
            records=[json.loads(p.read_text()) for p in files]
            assert all(x['status']=='complete' and x['episodes']==221 for x in records)
            assert len({x['input_manifest_sha256'] for x in records})==1
            fresh_gate(trial)
        elif args.phase=='inference':
            (trial/'INFERENCE_GO').write_text(str(time.time()))
            files=wait_workers(trial,'session_exit_code')
            assert all(p.read_text().strip()=='0' for p in files)
            predictions=list((trial/'workers').glob('*/predictions/timing_receipt.json'))
            assert len(predictions)==1
            from prepare_scoring_view import verify_handoff
            timing,_=verify_handoff(predictions[0].parent,trial/'qualification.json')
            put(trial/'inference_location.json',{'predictions':str(predictions[0].parent),'episodes':timing['episodes']})
        elif args.phase=='scoring_materialization':
            predictions=json.loads((trial/'inference_location.json').read_text())['predictions']
            run([PYTHON,'-B',str(ROOT/'source/prepare_scoring_view.py'),
                '--frozen-plan',str(ROOT/'source/baseline_receipts/plan_val.json'),
                '--pack',str(WORK/'packs/89f2501aa722cd12/bench_v2_val'),
                '--predictions',predictions,'--qualification',str(trial/'qualification.json'),'--out',str(score/'view')])
            run([PYTHON,'-B',str(ROOT/'source/baseline_archive/materialize_corrected_v3_units.py'),
                 '--phase','val','--expect-total','221','--plan',str(score/'view/plan.json'),
                 '--views-root',str(score/'view/views'),'--units-root',str(score/'units'),'--manifest',str(score/'units_manifest.json')])
        elif args.phase=='scoring':
            run(['bash',str(ROOT/'source/score_frozen_unit.sh'),str(unit)])
        elif args.phase=='aggregation':
            run([PYTHON,'-B',str(ROOT/'source/baseline_archive/create_validation_receipt.py'),
                '--plan',str(score/'view/plan.json'),'--inference-marker',str(score/'view/VAL_INFERENCE_COMPLETE.json'),
                '--units-manifest',str(score/'units_manifest.json'),'--unit',str(unit),'--out',str(score/'validation_receipt.json')])
            run(['bash',str(ROOT/'source/score_frozen_unit.sh'),str(unit),str(score/'aggregates')])
        print(json.dumps({'phase':args.phase,'status':'COMPLETE','validation_examples_inspected':False}))
    except BaseException:
        (trial/'ABORT').write_text('A phase failed; do not start another remote phase.\n')
        raise


if __name__=='__main__':main()
