"""Bound a task-owned subprocess group; never signal pre-existing processes."""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--deadline', required=True)
    p.add_argument('--seconds', type=float, default=7200)
    p.add_argument('--receipt', type=Path, required=True)
    p.add_argument('command', nargs=argparse.REMAINDER)
    args = p.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    deadline = datetime.datetime.fromisoformat(args.deadline.replace('Z', '+00:00')).timestamp()
    remaining = min(args.seconds, deadline - time.time())
    if remaining <= 30 or not command: raise SystemExit('insufficient deadline budget or no command')
    started = time.monotonic()
    child = subprocess.Popen(command, start_new_session=True)
    timed_out = False
    try:
        code = child.wait(timeout=remaining - 30)
    except subprocess.TimeoutExpired:
        timed_out = True
        # PID/PGID is the newly created child only, never discovered by a name.
        os.killpg(child.pid, signal.SIGTERM)
        try: code = child.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=10)
    finally:
        receipt = {'child_pid': child.pid, 'exit_code': child.poll(), 'deadline': args.deadline,
                   'timed_out': timed_out, 'elapsed_seconds': time.monotonic() - started,
                   'scope': 'only newly spawned task process group'}
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    raise SystemExit(124 if timed_out else code)


if __name__ == '__main__': main()
