"""Shared task-budget admission; reservations survive uncertain interruptions."""
import fcntl
import json
import math
import os
from pathlib import Path
import time

LIMITS = {'chip_hours': 64.0, 'validation': 5, 'qualification': 3}


def transact(path, operation):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+') as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        stream.seek(0)
        raw = stream.read()
        state = json.loads(raw) if raw else {'schema': 'relationadapter_trial_budget_v1', 'limits': LIMITS, 'trials': {}}
        if state.get('limits') != LIMITS: raise ValueError('budget limits differ from preregistration')
        result = operation(state)
        stream.seek(0); stream.truncate(); json.dump(state, stream, indent=2)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        return result


def reserve(path, trial_id, *, kind, candidate, max_chip_hours):
    if kind not in ['qualification', 'validation'] or candidate not in ['C0', 'C1', 'C0+C1']:
        raise ValueError('undeclared trial')
    if not 0 < max_chip_hours <= 16 or not math.isfinite(max_chip_hours):
        raise ValueError('per-trial budget outside two-hour v5p-16 limit')
    def update(state):
        trials = state['trials']
        if trial_id in trials: raise ValueError('trial id already used; retries require a new recorded trial')
        run_root=Path(path).parents[1]
        permission_path=run_root/'configs/qualification_attempt_limit_authorization.json'
        permission=None
        if permission_path.exists():
            permission=json.loads(permission_path.read_text())
            if (permission.get('authority')!='Direct user reply in this conversation'
                or permission.get('qualification_attempts_total_max')!=5
                or permission.get('total_chip_hours_max')!=64
                or permission.get('per_attempt_chip_hours_max')!=16):
                raise ValueError('explicit bounded qualification extension differs')
        elif kind=='qualification' and (run_root/'receipts/warm_retry_approval_block.json').exists():
            raise ValueError('automatic review requires explicit user approval before another qualification')
        if kind=='qualification' and permission is not None:
            if sum(x['kind']=='qualification' for x in trials.values())>=5:
                raise ValueError('explicit five-attempt qualification cap exhausted')
        infrastructure = [x for x in trials.values() if x.get('model_execution_started') is False]
        if infrastructure:
            amendment = Path(path).parents[1] / 'configs/infrastructure_attempt_amendment.json'
            policy = json.loads(amendment.read_text())
            if (policy.get('model_qualification_max') != 3 or policy.get('infrastructure_only_failures_max') != 6
                    or policy.get('total_accelerator_chip_hours_max') != 64):
                raise ValueError('infrastructure amendment differs')
            if len(infrastructure) >= 6: raise ValueError('finite infrastructure attempt allowance exhausted')
            import hashlib
            for item in infrastructure:
                proof = item['infrastructure_only_evidence']
                if (item['status'] != 'FAILED' or hashlib.sha256((Path(path).parents[1] / proof['path']).read_bytes()).hexdigest() != proof['sha256']):
                    raise ValueError('infrastructure-only terminal evidence differs')
        if not (kind=='qualification' and permission is not None) and sum(x['kind'] == kind and x.get('model_execution_started') is not False for x in trials.values()) >= LIMITS[kind]:
            raise ValueError('trial count exhausted')
        committed = sum(x.get('actual_chip_hours', x['reserved_chip_hours']) for x in trials.values())
        if committed + max_chip_hours > LIMITS['chip_hours']: raise ValueError('task chip-hour budget exhausted')
        trials[trial_id] = {'kind': kind, 'candidate': candidate, 'status': 'RESERVED',
                            'reserved_chip_hours': max_chip_hours, 'reserved_epoch': time.time()}
        return dict(trials[trial_id])
    return transact(path, update)


def finish(path, trial_id, *, actual_chip_hours, terminal_receipt_sha256, status):
    if status not in ['COMPLETE', 'FAILED'] or len(terminal_receipt_sha256) != 64:
        raise ValueError('terminal evidence required')
    def update(state):
        trial = state['trials'][trial_id]
        if trial['status'] != 'RESERVED': raise ValueError('trial already terminal')
        if not math.isfinite(actual_chip_hours) or not 0 <= actual_chip_hours <= trial['reserved_chip_hours']:
            raise ValueError('actual usage outside reservation; manual reconciliation required')
        trial.update(status=status, actual_chip_hours=actual_chip_hours,
                     terminal_receipt_sha256=terminal_receipt_sha256, finished_epoch=time.time())
        return dict(trial)
    return transact(path, update)
