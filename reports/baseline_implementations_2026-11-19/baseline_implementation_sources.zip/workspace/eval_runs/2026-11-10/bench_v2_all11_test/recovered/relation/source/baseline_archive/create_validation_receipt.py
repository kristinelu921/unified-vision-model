#!/usr/bin/env python3
"""Attest complete authoritative corrected-V3 scoring of the 221-query VAL split."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import relation_adapter_bench_v2 as R

PROTOCOL = "bench_v2_PP2_CSA_seed1_AP_FIRST_v1"
RELEASE = "bd08e05f1d0e9dd077db683f4f124ac49a2c45cd0ec5728653bd1ad66cc13792"


def regular_json(path: Path) -> tuple[dict, str]:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"regular JSON missing: {path}")
    return json.loads(path.read_text()), R.sha256_file(path)


def build_receipt(plan_path: Path, inference_marker_path: Path, units_manifest_path: Path,
                  unit: Path) -> dict:
    plan = R.validate_plan(plan_path)
    marker, marker_sha = regular_json(inference_marker_path)
    marker_expected = {
        "schema": "relation_adapter_bench_v2_validation_inference_complete_v1",
        "episodes": 221,
        "plan_identity": plan["plan_identity"],
    }
    if any(marker.get(key) != value for key, value in marker_expected.items()):
        raise ValueError("validation inference marker contract differs")
    qualification_sha = marker.get("qualification_receipt_sha256")
    if not isinstance(qualification_sha, str) or len(qualification_sha) != 64:
        raise ValueError("validation marker lacks the qualification receipt digest")
    units_manifest, units_manifest_sha = regular_json(units_manifest_path)
    if (units_manifest.get("schema") != "relation_adapter_bench_v2_native_p1_corrected_v3_units_manifest_v1"
            or units_manifest.get("phase") != "val"
            or units_manifest.get("plan_identity") != plan["plan_identity"]
            or units_manifest.get("corrected_release_sha256") != RELEASE
            or units_manifest.get("total_episodes") != 221
            or len(units_manifest.get("packs", [])) != 1
            or units_manifest["packs"][0].get("pack_rel") != "bench_v2_val"):
        raise ValueError("validation unit manifest contract differs")
    if unit.resolve() != Path(units_manifest["packs"][0]["unit"]).resolve():
        raise ValueError("validation unit path differs from unit manifest")
    producer, producer_sha = regular_json(unit / "results.json")
    score_root = unit / "scored_eval_v2"
    scored, scored_sha = regular_json(score_root / "results.json")
    score_manifest, score_manifest_sha = regular_json(score_root / "score_manifest.json")
    if (producer.get("provenance", {}).get("plan_identity") != plan["plan_identity"]
            or producer.get("data_identity", {}).get("pack_rel") != "bench_v2_val"
            or producer.get("prediction_complete") is not True
            or len(producer.get("episodes", {})) != 221
            or set(producer.get("episodes", {})) != set(producer.get("expected_episode_keys", []))):
        raise ValueError("validation producer contract differs")
    if units_manifest["packs"][0].get("producer_sha256") != producer_sha:
        raise ValueError("validation producer digest differs from unit manifest")
    metric_identity = score_manifest.get("metric_identity", {})
    if (score_manifest.get("schema") != "jflux2.bench_score_manifest.v1"
            or score_manifest.get("status") != "score_complete"
            or score_manifest.get("authoritative") is not True
            or score_manifest.get("requested_contract_satisfied") is not True
            or score_manifest.get("metric_contract") != "eval_v2"
            or score_manifest.get("episodes") != 221
            or score_manifest.get("scored_pairs") != 442
            or score_manifest.get("producer_sha256") != producer_sha
            or score_manifest.get("run_identity") != producer.get("run_identity")
            or metric_identity.get("metric_protocol") != PROTOCOL
            or metric_identity.get("release_sha256") != RELEASE):
        raise ValueError("validation corrected-V3 score receipt differs")
    outputs = score_manifest.get("outputs")
    if (not isinstance(outputs, dict)
            or set(outputs) != {"results.json", "lpips_v1.json", "keypoint_localisation_v1.json"}):
        raise ValueError("validation score output manifest is missing")
    for name, digest in outputs.items():
        path = score_root / name
        if Path(name).name != name or not isinstance(digest, str) or R.sha256_file(path) != digest:
            raise ValueError(f"validation score output differs: {name}")
    if (scored.get("complete") is not True or scored.get("score_complete") is not True
            or set(scored.get("episodes", {})) != set(producer["episodes"])
            or not all(ep.get("complete") is True and ep.get("score_complete") is True
                       for ep in scored["episodes"].values())):
        raise ValueError("validation scored coverage differs")
    return {
        "schema": "relation_adapter_bench_v2_validation_receipt_v1",
        "status": "authoritative_corrected_v3_validation_complete",
        "plan_identity": plan["plan_identity"],
        "episodes": 221,
        "metric_protocol": PROTOCOL,
        "release_sha256": RELEASE,
        "metric_identity_sha256": score_manifest["metric_identity_sha256"],
        "qualification_receipt_sha256": qualification_sha,
        "validation_inference_marker_sha256": marker_sha,
        "units_manifest_sha256": units_manifest_sha,
        "producer_sha256": producer_sha,
        "score_manifest_sha256": score_manifest_sha,
        "scored_results_sha256": scored_sha,
        "score_outputs": outputs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--inference-marker", type=Path, required=True)
    parser.add_argument("--units-manifest", type=Path, required=True)
    parser.add_argument("--unit", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        raise SystemExit("fresh validation receipt path required")
    try:
        receipt = build_receipt(args.plan, args.inference_marker, args.units_manifest, args.unit)
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        raise SystemExit(f"validation receipt refused: {exc}") from exc
    R.atomic_json(args.out, receipt)
    print(json.dumps({"receipt": str(args.out), "sha256": R.sha256_file(args.out)}, sort_keys=True))


if __name__ == "__main__":
    main()
