"""Deadline-bounded read-only availability monitor. Never launches workloads."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]
DEADLINE = datetime.datetime.fromisoformat('2026-10-31T01:04:27+00:00').timestamp()


def notify(message):
    req = urllib.request.Request('https://ntfy.sh/kluping', data=message.encode(),
                                  headers={'Title': 'RelationAdapter capacity update'})
    with urllib.request.urlopen(req, timeout=25) as response:
        receipt = json.load(response)
    if receipt.get('event') != 'message': raise RuntimeError('ntfy did not accept message')
    return {key: receipt.get(key) for key in ['id', 'event', 'time']}


def main():
    out = ROOT / 'receipts/capacity_monitor'
    out.mkdir(exist_ok=True)
    state = {'status': 'RUNNING_READ_ONLY', 'pid': os.getpid(), 'poll_seconds': 900,
             'deadline_utc': '2026-10-31T01:04:27Z', 'launches_workloads': False}
    last_candidates = None
    while time.time() < DEADLINE:
        now = datetime.datetime.now(datetime.timezone.utc)
        remaining = DEADLINE - time.time()
        if remaining < 120: break
        env = dict(os.environ, ELF_TPU_INITIALIZE_MISSING='0')
        try:
            result = subprocess.run(['bash', 'tpu_scripts/check_tpus.sh', 'he-vision-group'], cwd=REPO,
                                    env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, timeout=min(600, remaining - 30))
            path = out / (now.strftime('%Y%m%dT%H%M%SZ') + '.log')
            path.write_text(result.stdout)
            section = result.stdout.rsplit('\nAVAILABLE\n', 1)
            candidates = section[1].strip() if result.returncode == 0 and len(section) == 2 else None
            state.update({'checked_utc': now.isoformat(), 'inventory_exit_code': result.returncode,
                          'final_available': candidates, 'inventory_file': str(path.relative_to(ROOT))})
            if candidates not in (None, '', 'none') and candidates != last_candidates:
                state['notification'] = notify('RelationAdapter / relationadapter_autoresearch_010427: '
                    'Read-only inventory now reports authorized idle capacity. Full validation still needs '
                    'compatible topology, coordination, all-worker occupancy recheck and synthetic qualification. '
                    'Recommended next step: resume the prepared guarded qualification; no workload was launched by this monitor.')
            last_candidates = candidates
        except Exception as exc:
            state.update({'checked_utc': now.isoformat(), 'error_type': type(exc).__name__,
                          'final_available': None})
        (out / 'status.json').write_text(json.dumps(state, indent=2) + '\n')
        time.sleep(max(0, min(900, DEADLINE - time.time() - 120)))
    state['status'] = 'DEADLINE_REACHED_NO_MORE_CHECKS'
    state['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out / 'status.json').write_text(json.dumps(state, indent=2) + '\n')


if __name__ == '__main__': main()
