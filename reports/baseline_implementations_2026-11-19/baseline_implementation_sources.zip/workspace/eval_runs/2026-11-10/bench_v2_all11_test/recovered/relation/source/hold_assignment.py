"""Hold the shared local assignment lock for this explicitly authorized run.

Does not connect to, mutate, or signal anything on a TPU. Remote jobs have their
own deadlines. A stop request releases only this process's own local lock.
"""
import datetime
import fcntl
import json
import os
from pathlib import Path
import socket
import time
from execution_contract import require_authorized_resource

ROOT = Path(__file__).resolve().parents[1]
NAME = json.loads((ROOT / 'configs/resource_authorization.json').read_text())['resource']
ZONE = 'us-east5-a'


def main():
    require_authorized_resource(NAME)
    coordination = ROOT.parent / 'accelerator_assignments'
    coordination.mkdir(exist_ok=True)
    with (coordination / (NAME + '.lock')).open('a+') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        patterns = ['*/receipts/launch_request.json', '*/receipts/resource_claim.json',
                    '*/evidence/exclusive_assignment.json']
        for pattern in patterns:
            for path in ROOT.parent.glob(pattern):
                if path.is_relative_to(ROOT): continue
                value = json.loads(path.read_text())
                if NAME in [value.get('resource'), value.get('name'), value.get('tpu_name')]:
                    raise SystemExit('another loop has a recorded request or assignment')
        expires = min(time.time() + 14400, 1793408667)
        record = {'run_id': ROOT.name, 'tpu_name': NAME, 'resource': NAME, 'zone': ZONE,
                  'host': socket.gethostname(), 'pid': os.getpid(), 'status': 'HELD_PREPARING',
                  'concurrent_loops_acknowledged': True,
                  'coordination_evidence': 'shared exclusive flock plus current other-loop request/assignment scan',
                  'expires_epoch': expires, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        shared = coordination / (NAME + '.json')
        previous = json.loads(shared.read_text()) if shared.exists() else None
        if previous and previous.get('run_id') != ROOT.name:
            raise SystemExit('another loop has a shared assignment record')
        text = json.dumps(record, indent=2) + '\n'
        shared.write_text(text)
        (ROOT / 'receipts/shared_assignment.json').write_text(text)
        try:
            while time.time() < expires and not (ROOT / 'receipts/release_assignment').exists():
                time.sleep(min(10, max(0, expires - time.time())))
        finally:
            record['status'] = 'LOCAL_LOCK_RELEASED'
            record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            text = json.dumps(record, indent=2) + '\n'
            shared.write_text(text)
            (ROOT / 'receipts/shared_assignment.json').write_text(text)


if __name__ == '__main__': main()
