"""One bounded continuous setup/qualification session on the authorized slice."""
import datetime, hashlib, json, os, shlex, subprocess, time
from pathlib import Path
from trial_budget import reserve,finish

ROOT=Path(__file__).resolve().parents[1]
NAME='kmh-tpuvm-v5p-16-us-east5-spot-lyy-10291553guz'

def main():
    lease=json.loads((ROOT/'receipts/shared_assignment.json').read_text())
    cmd=(Path('/proc')/str(lease['pid'])/'cmdline').read_bytes().replace(b'\0',b' ').decode()
    assert str(ROOT/'source/hold_assignment.py') in cmd and lease['expires_epoch']>time.time()+7200
    first=json.loads((ROOT/'receipts/qualification_001_start.json').read_text())
    terminal={'status':'FAILED_STAGING_LOST_BEFORE_MODEL_START','observed_epoch':time.time(),
        'setup_completed':True,'model_calls':0,'evidence':'Both setup workers emitted SETUP_COMPLETE_ASSETS_VERIFIED. Subsequent read-only checks found own /dev/shm directory absent, unchanged boot start, RemoveIPC default=yes and Linger=no.',
        'accounting':'Conservative occupied-resource wall time from reservation until this recovery, including idle coordination.'}
    path=ROOT/'receipts/qualification_001_terminal.json'
    path.write_text(json.dumps(terminal,indent=2)+'\n')
    finish(ROOT/'receipts/trial_budget.json','qualification_001',actual_chip_hours=8*(time.time()-first['started_epoch'])/3600,
        terminal_receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),status='FAILED')
    budget=reserve(ROOT/'receipts/trial_budget.json','qualification_002',kind='qualification',candidate='C0+C1',max_chip_hours=16)
    start=time.time(); deadline=start+7200
    state={'status':'RUNNING','trial_id':'qualification_002','started_epoch':start,'deadline_epoch':deadline,
        'budget':budget,'tpu_name':NAME,'workers':2,'physical_chips':8,'source_bundle':'bundle_v1',
        'recovery':'same source and scientific recipe; continuous session retains node-local shared-memory files'}
    state_path=ROOT/'receipts/qualification_002_controller.json'
    state_path.write_text(json.dumps(state,indent=2)+'\n')
    gate=ROOT/'receipts/qualification_002_fresh_gate.json'
    subprocess.run(['python3','-B',str(ROOT/'source/prelaunch_gate.py'),'--name',NAME,'--zone','us-east5-a',
        '--inventory',str(ROOT/'receipts/search_014006/kristine_inventory.log'),
        '--inventory-receipt',str(ROOT/'receipts/search_014006/kristine_inventory_receipt.json'),
        '--assignment',str(ROOT/'receipts/shared_assignment.json'),'--out',str(gate)],check=True)
    remote="python3 -B "+shlex.quote(str(ROOT/'source/deadline_exec.py'))+" --deadline "+datetime.datetime.fromtimestamp(deadline,datetime.timezone.utc).isoformat()+" --seconds 7200 --receipt "+shlex.quote(str(ROOT/'receipts/qualification_002/deadline_'))+'"$(hostname)"'+".json -- bash "+shlex.quote(str(ROOT/'source/qualify_continuous_remote.sh'))
    argv=['gcloud','compute','tpus','tpu-vm','ssh',NAME,'--project=he-vision-group','--zone=us-east5-a',
        '--worker=all','--internal-ip','--ssh-flag=-F','--ssh-flag=/dev/null','--command='+remote]
    with (ROOT/'receipts/qualification_002_transport.log').open('x') as log:
        result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
    state.update(status='SESSION_COMPLETE' if result.returncode==0 else 'FAILED',exit_code=result.returncode,
        finished_epoch=time.time(),elapsed_seconds=time.time()-start)
    state_path.write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps(state))
    raise SystemExit(result.returncode)

if __name__=='__main__': main()
