"""Freeze the synthetic-qualified recipe and execute the full validation once."""
import hashlib
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import time
from execution_contract import hardware_profile, validate_qualification
from measure_full_trial import execute, PHASES

ROOT=Path(__file__).resolve().parents[1]
NAME='kmh-tpuvm-v5p-64-us-east5-spot-jaustin-aj4jza'
WORK=Path('/tmp/relationadapter_autoresearch_010427/scoring')


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda:f.read(8<<20),b''):h.update(data)
    return h.hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--qualification-attempt',choices=['qualification_004','qualification_005'],default='qualification_004')
    label=parser.parse_args().qualification_attempt
    attempt=ROOT/'receipts'/label
    controller=json.loads((ROOT/'receipts'/(label+'_controller.json')).read_text())
    if controller['status']!='COMPLETE':raise SystemExit('complete synthetic qualification required')
    exit_name='qualification_exit_code' if label=='qualification_005' else 'session_exit_code'
    exits=list(attempt.glob('*/'+exit_name))
    if len(exits)!=8 or any(p.read_text().strip() not in ['0','1'] for p in exits):
        raise SystemExit('all-worker terminal evidence differs')
    references=list(attempt.glob('*/'+label+'/C0.json'))
    if len(references)!=1:raise SystemExit('exactly one writer reference receipt required')
    reference=json.loads(references[0].read_text())
    validate_qualification(reference,candidate='C0',tpu_name=NAME,runtime_identity=reference['runtime_identity'])
    workers=list(attempt.glob('*/telemetry_'+label+'/worker_*.json'))
    values=[json.loads(p.read_text()) for p in workers]
    if (len(values)!=8 or {v['worker_index'] for v in values}!=set(range(8))
        or any(v['global_devices']!=32 or v['addressable_devices']!=4 or v['runtime_identity']!=reference['runtime_identity'] for v in values)):
        raise SystemExit('all-worker qualification identity/coverage differs')
    selected=references[0]
    candidate='C0'
    optimized=references[0].with_name('C1.json')
    if optimized.exists():
        receipt=json.loads(optimized.read_text())
        if receipt.get('status')=='PASS' and receipt.get('C1_speed_gate_passed') is True:
            validate_qualification(receipt,candidate='C1',tpu_name=NAME,runtime_identity=reference['runtime_identity'])
            selected=optimized;candidate='C1'
    trial=ROOT/'trials/validation_001'
    trial.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(selected,trial/'qualification.json')
    choice={'candidate':candidate,'qualification_sha256':sha(trial/'qualification.json'),
            'qualification_source':str(selected.relative_to(ROOT)),
            'resource':NAME,'runtime_identity':reference['runtime_identity'],
            'frozen_before_validation_access':True,'selection_basis':'preregistered synthetic exactness and median warm speed only'}
    snapshots=ROOT/'cache_snapshots/qualification_004_startup'
    late=ROOT/'cache_snapshots/qualification_004_late'
    if len(list(late.glob('*/COMPLETE')))==8:snapshots=late
    for directory in ['qualification_004_recovered','qualification_005_complete']:
        path=ROOT/'cache_snapshots'/directory
        if len(list(path.glob('*/COMPLETE')))==8:snapshots=path
    snapshot_files={}
    for worker in sorted(p.name for p in attempt.iterdir() if p.is_dir()):
        snapshot=snapshots/worker
        if not (snapshot/'COMPLETE').is_file():break
        lines=(snapshot/'SHA256SUMS').read_text().splitlines()
        if not lines:raise SystemExit('empty cache snapshot')
        for line in lines:
            digest,name=line.split('  ',1)
            parts=Path(name).parts
            if (len(parts)!=2 or parts[0]!=reference['runtime_identity'] or not parts[1].isdigit()
                or sha(snapshot/'files'/name)!=digest):raise SystemExit('compilation cache snapshot differs')
        snapshot_files[worker]=sha(snapshot/'SHA256SUMS')
    if len(snapshot_files)==8:
        choice.update(cache_snapshot_root=str(snapshots),cache_snapshot_manifests=snapshot_files,
                      compilation_cache_condition='partial_warm_verified')
    else:choice['compilation_cache_condition']='cold_empty'
    gate=trial/'before_staging_gate.json'
    subprocess.run(['python3','-B',str(ROOT/'source/prelaunch_gate.py'),'--name',NAME,'--zone','us-east5-a',
        '--inventory',str(ROOT/'receipts/non_kristine_search_0207/kristine_inventory.log'),
        '--inventory-receipt',str(ROOT/'receipts/non_kristine_search_0207/kristine_inventory_receipt.json'),
        '--assignment',str(ROOT/'receipts/shared_assignment.json'),'--out',str(gate)],check=True)
    choice['accelerator_deadline_epoch']=int(time.time())+1800
    (trial/'selection.json').write_text(json.dumps(choice,indent=2)+'\n')
    writer=references[0].parents[1].name
    score=WORK/'corrected_v3_val/validation_001'
    config={'trial_id':'validation_001','candidate':candidate,'hardware':hardware_profile(),
        'coverage':{'tasks':13,'queries_per_task':17,'episodes':221},
        'cache_condition':'warm_verified','compile_cache':str(WORK/'unused_local_cache'),
        'cache_detail':'CPU scorer assets are reused after hashing; TPU weights/runtime are restaged. Compilation condition: '+choice['compilation_cache_condition']+'. Stable executable snapshots require per-worker runtime and transfer hashes. Original cold preparation is separately reported; this is not a cold-download total.',
        'shared_assignment_confirmed':True,'tpu_name':NAME,'occupancy_receipt':str(gate),
        'occupancy_receipt_sha256':sha(gate),'assignment_receipt':str(ROOT/'receipts/shared_assignment.json'),
        'assignment_receipt_sha256':sha(ROOT/'receipts/shared_assignment.json'),
        'chip_hour_budget':16,'budget_file':str(ROOT/'receipts/trial_budget.json'),
        'runtime_identity':reference['runtime_identity'],
        'inference_receipt':str(trial/'workers'/writer/'predictions/timing_receipt.json'),
        'score_manifest':str(score/'units/bench_v2_val/scored_eval_v2/score_manifest.json'),
        'validation_receipt':str(score/'validation_receipt.json'),
        'inference_marker':str(score/'view/VAL_INFERENCE_COMPLETE.json'),
        'phases':[{'name':name,'reserved_chips':32 if i<4 else 0,
            'argv':['python3','-B',str(ROOT/'source/validation_phases.py'),'--trial','validation_001','--phase',name]}
            for i,name in enumerate(PHASES)]}
    commands=trial/'commands.json';commands.write_text(json.dumps(config,indent=2)+'\n')
    (trial/'commands.sha256').write_text(sha(commands)+'\n')
    result=execute(config,trial/'timing')
    print(json.dumps({k:result[k] for k in ['status','end_to_end_seconds','slice_chip_hours','one_hour_target_met']}))


if __name__=='__main__':main()
