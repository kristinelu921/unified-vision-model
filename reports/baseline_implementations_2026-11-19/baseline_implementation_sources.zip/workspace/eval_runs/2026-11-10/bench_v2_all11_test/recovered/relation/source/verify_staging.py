"""Verify pinned dependencies, official sources, and every staged model asset."""
from pathlib import Path
import json
import socket
import time
from run_target_free import load_baseline
from execution_contract import check_official_source, production_environment, source_identity

root=Path(__file__).resolve().parents[1]
import platform
assert platform.python_version()=='3.10.19', 'Pinned common Python interpreter required'
base=load_baseline()
receipt=json.loads((root/'source/baseline_receipts/backend.val.json').read_text())
assert receipt['license_acknowledgement']==base.LICENSE_ACK
(root/'FLUX_LICENSE_ACK').write_text(receipt['license_acknowledgement']+'\n')
check_official_source(root/'official/repo')
assets={n:base.verify_asset_tree(root/'assets'/n,base.ASSET_MANIFESTS[n])
    for n in ['FLUX.1-dev','RelationAdapter','siglip-so400m-patch14-384']}
result={'status':'SETUP_COMPLETE_ASSETS_VERIFIED','worker':socket.gethostname(),
    'completed_epoch':time.time(),'assets':assets,'environment':production_environment(),
    'source_identity':source_identity(),'node_local':True,'asset_region':'us-east5'}
(root/'setup_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'worker':result['worker']}),flush=True)
