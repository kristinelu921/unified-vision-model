"""One-use continuation; validation's own fresh gates remain authoritative."""
import json
import argparse
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--attempt',choices=['qualification_004','qualification_005'],default='qualification_004')
    label=parser.parse_args().attempt
    status=ROOT/('receipts/validation_continuation_'+label+'.json')
    with status.open('x') as f:json.dump({'status':'WAITING_FOR_QUALIFICATION'},f)
    while True:
        q=json.loads((ROOT/'receipts'/(label+'_controller.json')).read_text())
        if q['status'] in ['COMPLETE','FAILED']:break
        if time.time()>q['deadline_epoch']+120:
            status.write_text(json.dumps({'status':'STOPPED_UNCERTAIN_QUALIFICATION','launch_attempted':False}))
            return
        time.sleep(10)
    if q['status']!='COMPLETE':
        status.write_text(json.dumps({'status':'STOPPED_QUALIFICATION_FAILED','launch_attempted':False}))
        return
    status.write_text(json.dumps({'status':'VALIDATION_GATE_AND_EXECUTION','launch_attempted':True}))
    with (ROOT/'receipts/validation_001_controller.log').open('x') as log:
        result=subprocess.run(['python3','-B',str(ROOT/'source/launch_validation_001.py'),'--qualification-attempt',label],stdout=log,stderr=subprocess.STDOUT)
    status.write_text(json.dumps({'status':'VALIDATION_COMPLETE' if result.returncode==0 else 'VALIDATION_FAILED_OR_GATE_REFUSED',
                                 'launch_attempted':True,'exit_code':result.returncode,'finished_epoch':time.time()},indent=2)+'\n')


if __name__=='__main__':main()
