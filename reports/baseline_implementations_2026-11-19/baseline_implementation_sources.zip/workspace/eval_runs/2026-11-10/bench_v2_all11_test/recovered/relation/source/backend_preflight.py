"""Construct the frozen full backend using metadata only; compute no metric."""
import json
from pathlib import Path
import time
from tools.bench_eval_v3_backend_v1 import CorrectedBackend

ROOT=Path(__file__).resolve().parents[1]
SHARED=Path('/kmh-nfs-ssd-us-mount/code/xtiange/jflux2')
BASE=SHARED/'docs/bench_v2_gt_ceiling_tpu_v1_2026-10-07'
WORK=Path('/tmp/relationadapter_autoresearch_010427/scoring')
start=time.monotonic()
backend=CorrectedBackend(
    release_pin={'path':str(BASE/'corrected_metric_release_v3/release_manifest.json'),'sha256':'bd08e05f1d0e9dd077db683f4f124ac49a2c45cd0ec5728653bd1ad66cc13792'},
    host_build_pin={'path':str(BASE/'cpu_reference_v2/bsds_matching_review_v1/build_receipt_v3.json'),'sha256':'55112291ec00a2cadde799409809d08133de3e3dabc681d03bd96225c1bfcc16'},
    host_admission_pin={'path':str(BASE/'corrected_metric_release_v1_preparation_v1/LOCAL_HOST_CERTIFICATE_V3.json'),'sha256':'710d3ec5ac665c42bec5884ae08556e7251a6771b074bdb3159ee7c9b001637b'},
    gt_manifest=SHARED/'docs/eval_v2_2026-10-06/gt_sidecar_manifest_v1.json',
    gt_manifest_sha256='96b6a970a8d29268b7c194b015956952e537dbdf974dc505532acef8a1f81811',
    metric_protocol_sha256='2d8a72034245d9e6f95a8ce98c342cddaa96ac8b6b85d411ef2ae7a551f2b910',
    pack_manifest=SHARED/'docs/bench_v2_audit/manifest_v1.json',
    pack_manifest_sha256='89f2501aa722cd121da12e33a24ac9037d5cf50df7627911b7f6ce22fcd6c49d',
    bsds_manifest=SHARED/'docs/eval_v2_2026-10-06/bsds_v1/gt_bsds_manifest_v1.json',
    bsds_manifest_sha256='a42dbe60ed97e5acbcf59edd802f03e51a386331f69d623ea70bf35067ad27a1',
    bsds_root=WORK/'corrected_v3/assets/bench_v2_gt_v1_bsds',
    pack_root=WORK/'packs/89f2501aa722cd12',gt_root=WORK/'corrected_v3/assets/bench_v2_gt_v1',
    appearance_mode='preload')
receipt={'status':'FULL_FROZEN_BACKEND_ADMISSION_PASS','seconds':time.monotonic()-start,
    'validation_examples_opened':False,'test_payloads_opened':False,'test_metadata_stat_only':True,
    'test_open_guard_active':True,'metrics_computed':False,'metric_protocol':backend.identity['metric_protocol'],
    'release_sha256':backend.identity['release_sha256']}
(ROOT/'receipts/full_backend_preflight.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
