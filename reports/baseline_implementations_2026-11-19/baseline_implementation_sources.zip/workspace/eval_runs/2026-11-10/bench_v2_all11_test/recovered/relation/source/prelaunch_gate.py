"""Exact-resource read-only gate after successful filtered launch selection."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import subprocess
import time
from execution_contract import require_authorized_resource, hardware_profile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]


def selected_from_final_available(text, name, zone):
    sections = text.rsplit('\nAVAILABLE\n', 1)
    if len(sections) != 2: return False
    return any(len(fields := line.split()) >= 2 and fields[0] == name and fields[1] == zone
               for line in sections[1].splitlines())


def validate_cloud_description(description, name, zone):
    require_authorized_resource(name)
    full = description.get('name', '')
    if full.split('/')[-1] != name or '/locations/' + zone + '/' not in full:
        raise ValueError('cloud resource identity differs')
    if description.get('state') != 'READY' or description.get('health') != 'HEALTHY':
        raise ValueError('resource is not READY and HEALTHY')
    hardware = hardware_profile()
    if description.get('acceleratorType') != hardware['accelerator']: raise ValueError('declared accelerator required')
    topology = description.get('acceleratorConfig', {}).get('topology')
    if topology != hardware['topology']: raise ValueError('topology differs')
    if len(description.get('networkEndpoints', [])) != hardware['workers']: raise ValueError('worker count differs')
    if description.get('schedulingConfig', {}).get('spot') is not hardware['spot']: raise ValueError('Spot policy differs')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--name', required=True); p.add_argument('--zone', required=True)
    p.add_argument('--inventory', type=Path, required=True)
    p.add_argument('--inventory-receipt', type=Path, required=True)
    p.add_argument('--assignment', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    require_authorized_resource(args.name)
    evidence = json.loads(args.inventory_receipt.read_text())
    if (evidence.get('exit_code') != 0 or evidence.get('initialize_missing') != 0
            or evidence.get('inventory_sha256') != hashlib.sha256(args.inventory.read_bytes()).hexdigest()
            or ('kristine' in args.name.lower() and not 0 <= time.time() - evidence.get('completed_epoch', 0) <= 120)):
        raise SystemExit('recent successful read-only reconciler receipt required')
    if 'kristine' in args.name.lower() and not selected_from_final_available(args.inventory.read_text(), args.name, args.zone):
        raise SystemExit('selected resource is absent from final AVAILABLE')
    assignment = json.loads(args.assignment.read_text())
    if (assignment.get('tpu_name') != args.name or assignment.get('zone') != args.zone
            or assignment.get('run_id') != ROOT.name or assignment.get('concurrent_loops_acknowledged') is not True
            or assignment.get('status') != 'HELD_PREPARING'
            or assignment.get('expires_epoch', 0) <= time.time()):
        raise SystemExit('confirmed current shared assignment required')
    holder = Path('/proc') / str(assignment.get('pid', -1)) / 'cmdline'
    if not holder.exists() or str(ROOT / 'source/hold_assignment.py') not in holder.read_bytes().replace(b'\0', b' ').decode():
        raise SystemExit('shared assignment holder is no longer live')
    describe = subprocess.run(['gcloud', 'compute', 'tpus', 'tpu-vm', 'describe', args.name,
        '--project=he-vision-group', '--zone=' + args.zone, '--format=json'], capture_output=True, text=True, check=True, timeout=60)
    description = json.loads(describe.stdout)
    validate_cloud_description(description, args.name, args.zone)
    if 'kristine' in args.name.lower():
        command = ['bash', str(REPO / '.agents/skills/query-monitor-gcp-tpus/scripts/check_tpu_occupancy.sh'),
                   'he-vision-group', args.name, args.zone]
    else:
        # The repository helper rejects non-kristine IDs before it can apply the
        # explicit authorization exception. Use the recorded strictly read-only
        # fleet probe for this exact authorized ID; no claim/cleanup capability.
        probe = (ROOT / 'receipts/search_014006/readonly_probe.sh').read_text()
        command = ['gcloud', 'compute', 'tpus', 'tpu-vm', 'ssh', args.name,
                   '--project=he-vision-group', '--zone=' + args.zone, '--worker=all', '--internal-ip',
                   '--ssh-flag=-F', '--ssh-flag=/dev/null', '--ssh-flag=-o', '--ssh-flag=ConnectTimeout=12',
                   '--command=' + probe]
    result = subprocess.run(command, capture_output=True, text=True, timeout=120)
    # Keep the raw occupancy evidence; parsing is intentionally fail-closed.
    output = result.stdout + result.stderr
    # Preserve failed gates as well as successful admissions. Never retry or
    # mutate a holder merely because the gate's command returned nonzero.
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.with_suffix('.occupancy.log').write_text(output)
    if result.returncode != 0 or any(x in output for x in ['UNKNOWN', 'OCCUPIED', 'RECLAIMABLE', 'STALE_LOCK']):
        raise SystemExit('occupancy is unavailable or unknown')
    available_workers = set(re.findall(r'^AVAILABLE worker=(\S+)', output, re.MULTILINE))
    if len(available_workers) != hardware_profile()['workers']:
        raise SystemExit('occupancy helper did not prove AVAILABLE on every declared worker')
    receipt = {'schema': 'relationadapter_exact_resource_gate_v1', 'status': 'AVAILABLE',
        'tpu_name': args.name, 'zone': args.zone, 'checked_epoch': time.time(), 'description': description,
        'occupancy_output': output, 'occupancy_exit_code': result.returncode,
        'inventory_sha256': evidence['inventory_sha256'],
        'assignment_sha256': hashlib.sha256(args.assignment.read_bytes()).hexdigest()}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('x') as f: json.dump(receipt, f, indent=2)
    print(json.dumps({'status': 'AVAILABLE', 'resource': args.name, 'zone': args.zone, 'accelerator': hardware_profile()['accelerator']}))


if __name__ == '__main__': main()
