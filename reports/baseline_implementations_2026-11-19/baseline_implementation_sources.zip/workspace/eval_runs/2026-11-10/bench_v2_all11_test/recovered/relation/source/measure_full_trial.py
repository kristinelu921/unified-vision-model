"""Measure a complete frozen trial from staging through aggregate scoring.

Consumes a reviewed command manifest; never discovers or acquires hardware.
Each command is an argv list (no shell evaluation). A controller is not a TPU
authorization: the caller must attach current occupancy/assignment receipts.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
from trial_budget import reserve, finish
from execution_contract import require_authorized_resource, hardware_profile

PHASES = ['staging', 'environment', 'input_export', 'inference', 'scoring_materialization', 'scoring', 'aggregation']
CHIPS = dict(zip(PHASES, [hardware_profile()['global_devices']] * 4 + [0, 0, 0]))
DEADLINE = datetime.datetime.fromisoformat('2026-10-31T01:04:27+00:00').timestamp()


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def terminate_created_child(child):
    if child.poll() is not None: return
    os.killpg(child.pid, signal.SIGTERM)
    try: child.wait(timeout=20)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        child.wait(timeout=10)


def run_command(argv, *, logfile, seconds):
    if not argv or any(not isinstance(x, str) for x in argv): raise ValueError('explicit argv required')
    if seconds <= 30: raise TimeoutError('insufficient task deadline budget')
    tick = time.monotonic()
    with Path(logfile).open('xb') as log:
        child = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try: code = child.wait(timeout=seconds - 30)
        except subprocess.TimeoutExpired:
            terminate_created_child(child)
            return {'exit_code': 124, 'timed_out': True, 'seconds': time.monotonic() - tick}
        except BaseException:
            terminate_created_child(child)
            raise
    return {'exit_code': code, 'timed_out': False, 'seconds': time.monotonic() - tick}


def verify_complete_artifacts(config):
    inference_path = Path(config['inference_receipt'])
    scoring_path = Path(config['score_manifest'])
    inference, scoring = json.loads(inference_path.read_text()), json.loads(scoring_path.read_text())
    if (inference.get('episodes') != 221 or inference.get('status') != 'INFERENCE_COMPLETE_SCORING_REQUIRED'
            or inference.get('fresh_predictions') is not True or len(inference.get('outputs', [])) != 221):
        raise ValueError('fresh complete inference is unproven')
    if [x.get('ordinal') for x in inference['outputs']] != list(range(221)):
        raise ValueError('inference artifact coverage differs')
    for record in inference['outputs']:
        if Path(record['path']).name != record['path'] or sha(inference_path.parent / record['path']) != record['sha256']:
            raise ValueError('inference artifact changed after scoring handoff')
    metric = scoring.get('metric_identity', {})
    if (scoring.get('status') != 'score_complete' or scoring.get('authoritative') is not True
            or scoring.get('episodes') != 221 or scoring.get('scored_pairs') != 442
            or scoring.get('requested_contract_satisfied') is not True
            or metric.get('metric_protocol') != 'bench_v2_PP2_CSA_seed1_AP_FIRST_v1'
            or metric.get('release_sha256') != 'bd08e05f1d0e9dd077db683f4f124ac49a2c45cd0ec5728653bd1ad66cc13792'):
        raise ValueError('frozen complete scoring is unproven')
    outputs = scoring.get('outputs', {})
    if set(outputs) != {'results.json', 'lpips_v1.json', 'keypoint_localisation_v1.json'}:
        raise ValueError('scored artifact manifest differs')
    for name, expected in outputs.items():
        if sha(scoring_path.parent / name) != expected: raise ValueError('scored artifact changed')
    # Admission is also bound by the fresh candidate validation receipt, not just
    # a possibly unrelated score manifest reporting the right episode count.
    validation_path = Path(config['validation_receipt'])
    validation = json.loads(validation_path.read_text())
    if (validation.get('status') != 'authoritative_corrected_v3_validation_complete'
            or validation.get('episodes') != 221 or validation.get('score_manifest_sha256') != sha(scoring_path)):
        raise ValueError('validation receipt does not bind scoring')
    marker_path = Path(config['inference_marker'])
    marker = json.loads(marker_path.read_text())
    if (validation.get('validation_inference_marker_sha256') != sha(marker_path)
            or marker.get('fresh_predictions_receipt_sha256') != sha(inference_path)):
        raise ValueError('validation receipt does not bind fresh inference')
    return {'inference_receipt_sha256': sha(inference_path), 'score_manifest_sha256': sha(scoring_path),
            'validation_receipt_sha256': sha(validation_path)}


def execute(config, out):
    if config.get('hardware') != hardware_profile(): raise ValueError('declared hardware differs')
    if [x.get('name') for x in config['phases']] != PHASES:
        raise ValueError('all staging/inference/scoring phases required in fixed order')
    if config.get('candidate') not in ['C0', 'C1'] or config.get('coverage') != {'tasks': 13, 'queries_per_task': 17, 'episodes': 221}:
        raise ValueError('frozen candidate and complete coverage required')
    if config.get('cache_condition') not in ['cold_empty', 'warm_verified']:
        raise ValueError('cold/warm cache condition required')
    if config.get('cache_condition') == 'cold_empty':
        cache = Path(config['compile_cache'])
        if cache.exists() and any(cache.iterdir()): raise ValueError('cold trial cannot use a populated compilation cache')
    if config.get('shared_assignment_confirmed') is not True:
        raise ValueError('concurrent-loop assignment has not been confirmed')
    require_authorized_resource(config.get('tpu_name', ''))
    for field in ['occupancy_receipt', 'assignment_receipt']:
        if sha(config[field]) != config.get(field + '_sha256'): raise ValueError(field + ' identity differs')
    occupancy = json.loads(Path(config['occupancy_receipt']).read_text())
    if (occupancy.get('status') != 'AVAILABLE' or occupancy.get('tpu_name') != config['tpu_name']
            or not 0 <= time.time() - occupancy.get('checked_epoch', 0) <= 120):
        raise ValueError('recent exact-resource occupancy proof required')
    if float(config.get('chip_hour_budget', 0)) <= 0 or config['chip_hour_budget'] > 64:
        raise ValueError('remaining preregistered chip-hour budget required')
    out.mkdir(parents=True, exist_ok=False)
    reserve(config['budget_file'], config['trial_id'], kind='validation', candidate=config['candidate'], max_chip_hours=16.0)
    receipt = {'schema': 'relationadapter_full_trial_timing_v1', 'status': 'RUNNING',
               'candidate': config['candidate'], 'cache_condition': config['cache_condition'],
               'phases': [], 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'hardware': config['hardware'], 'end_to_end_seconds': None, 'slice_chip_hours': 0.0,
               'runtime_snapshot': config.get('runtime_identity'), 'one_hour_target_met': False}
    receipt['trial_id'] = config['trial_id']
    start = time.monotonic()
    try:
        for phase in config['phases']:
            chips = phase['reserved_chips']
            if type(chips) is not int or chips != CHIPS[phase['name']]: raise ValueError('phase chip accounting differs')
            remaining_hours = min(config['chip_hour_budget'], hardware_profile()['max_chip_hours_per_trial']) - receipt['slice_chip_hours']
            limits = [DEADLINE - time.time(), 7200 - (time.monotonic() - start)]
            if chips: limits.append(remaining_hours * 3600 / chips)
            measured = run_command(phase['argv'], logfile=out / (phase['name'] + '.log'), seconds=min(limits))
            measured.update({'phase': phase['name'], 'reserved_chips': chips})
            receipt['phases'].append(measured)
            receipt['slice_chip_hours'] += measured['seconds'] * chips / 3600
            receipt['elapsed_seconds'] = time.monotonic() - start
            (out / 'progress.json').write_text(json.dumps(receipt, indent=2) + '\n')
            if measured['exit_code'] != 0: raise RuntimeError('phase failed: ' + phase['name'])
        receipt['artifact_binding'] = verify_complete_artifacts(config)
        receipt['status'] = 'COMPLETE_FROZEN_VALIDATION_AND_SCORING'
        receipt['end_to_end_seconds'] = time.monotonic() - start
        receipt['one_hour_target_met'] = receipt['end_to_end_seconds'] <= 3600
    except BaseException as exc:
        receipt['status'] = 'INCOMPLETE'
        receipt['failure_type'] = type(exc).__name__
        raise
    finally:
        receipt['elapsed_seconds'] = time.monotonic() - start
        receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        if receipt['status'] == 'COMPLETE_FROZEN_VALIDATION_AND_SCORING':
            finish(config['budget_file'], config['trial_id'], actual_chip_hours=receipt['slice_chip_hours'],
                   terminal_receipt_sha256=sha(out / 'receipt.json'), status='COMPLETE')
        # An incomplete remote phase can outlive its local transport. Preserve
        # its full reservation until worker termination/usage is independently
        # verified; never refund a possibly active run on observation failure.
    return receipt


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--commands', type=Path, required=True)
    p.add_argument('--commands-sha256', required=True)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    if sha(args.commands) != args.commands_sha256: raise SystemExit('command manifest differs')
    receipt = execute(json.loads(args.commands.read_text()), args.out)
    print(json.dumps({key: receipt[key] for key in ['status', 'end_to_end_seconds', 'slice_chip_hours', 'one_hour_target_met']}))


if __name__ == '__main__': main()
