"""One-use, bounded setup and synthetic qualification on the authorized v5p-64."""
import hashlib
import json
import re
from pathlib import Path
import shlex
import subprocess
import time
from trial_budget import reserve, finish
from execution_contract import hardware_profile, require_authorized_resource, source_identity

ROOT = Path(__file__).resolve().parents[1]
NAME = 'kmh-tpuvm-v5p-64-us-east5-spot-jaustin-aj4jza'
TRIAL = ROOT / 'receipts/qualification_005'


def gate(suffix):
    path = ROOT / ('receipts/qualification_005_' + suffix + '_gate.json')
    subprocess.run(['python3', '-B', str(ROOT / 'source/prelaunch_gate.py'),
        '--name', NAME, '--zone', 'us-east5-a',
        '--inventory', str(ROOT / 'receipts/non_kristine_search_0207/kristine_inventory.log'),
        '--inventory-receipt', str(ROOT / 'receipts/non_kristine_search_0207/kristine_inventory_receipt.json'),
        '--assignment', str(ROOT / 'receipts/shared_assignment.json'), '--out', str(path)], check=True)
    return json.loads(path.read_text())


def main():
    permission_path=ROOT/'configs/qualification_attempt_limit_authorization.json'
    if not permission_path.is_file():raise SystemExit('explicit approval of one additional qualification attempt is pending')
    permission=json.loads(permission_path.read_text())
    if (permission.get('authority')!='Direct user reply in this conversation'
        or permission.get('qualification_attempts_total_max')!=5
        or permission.get('total_chip_hours_max')!=64 or permission.get('per_attempt_chip_hours_max')!=16):
        raise SystemExit('explicit bounded attempt-cap extension is missing')
    previous=json.loads((ROOT/'receipts/qualification_004_controller.json').read_text())
    if previous['status']!='FAILED':raise SystemExit('prior attempt is not terminal failed')
    for p in (ROOT/'receipts/qualification_004').glob('*/telemetry_qualification_004/progress_worker_*.json'):
        if json.loads(p.read_text())['completed_fixture_comparisons']!=0:
            raise SystemExit('completed comparisons require review before any retry')
    if list((ROOT/'receipts/qualification_004').glob('*/qualification_004/C*.json')):
        raise SystemExit('candidate outcome exists; no automatic warm retry')
    require_authorized_resource(NAME)
    hardware = hardware_profile()
    assert hardware['workers'] == 8 and hardware['global_devices'] == 32
    admission=gate('before_staging')
    workers=sorted(set(re.findall(r'^AVAILABLE worker=(\S+)',admission['occupancy_output'],re.MULTILINE)))
    assert len(workers)==8
    TRIAL.mkdir(exist_ok=False)
    for worker in workers:(TRIAL/worker).mkdir()
    budget = reserve(ROOT / 'receipts/trial_budget.json', 'qualification_005',
                     kind='qualification', candidate='C0+C1', max_chip_hours=16)
    start = time.time()
    deadline = min(int(start) + 1800, 1793408667)
    state = {'status': 'STAGING', 'trial_id': 'qualification_005', 'resource': NAME,
        'started_epoch': start, 'deadline_epoch': deadline, 'budget': budget,
        'hardware': hardware, 'source_identity': source_identity(),
        'accounting': '32 physical chips times complete staging-to-session-exit wall; hard task-group deadline includes staging',
        'sessions_retain_assets_until_qualification_finishes': True, 'compilation_cache_condition':'partial_warm_verified', 'cache_plan':'configs/qualification_005_cache.json'}
    path = ROOT / 'receipts/qualification_005_controller.json'
    def save(): path.write_text(json.dumps(state, indent=2) + '\n')
    save()
    remote = 'bash ' + shlex.quote(str(ROOT / 'source/qualify_v5p64_warm_remote.sh')) + ' ' + str(deadline)
    argv = ['gcloud', 'compute', 'tpus', 'tpu-vm', 'ssh', NAME, '--project=he-vision-group',
            '--zone=us-east5-a', '--worker=all', '--internal-ip', '--ssh-flag=-F',
            '--ssh-flag=/dev/null', '--command=' + remote]
    failure = None
    with (ROOT / 'receipts/qualification_005_transport.log').open('x') as log:
        process = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT)
        try:
            while True:
                setups=[]
                for worker in workers:
                    candidate=TRIAL/worker/'setup_receipt.json'
                    try:candidate.read_text()
                    except FileNotFoundError:continue
                    setups.append(candidate)
                if len(setups) == 8:
                    assert all(json.loads(p.read_text())['status'] == 'SETUP_COMPLETE_ASSETS_VERIFIED' for p in setups)
                    state.update(status='POST_SETUP_OCCUPANCY_CHECK', staging_seconds=time.time()-start)
                    save()
                    gate('after_staging')
                    (TRIAL / 'GO').write_text(str(time.time()) + '\n')
                    state.update(status='SYNTHETIC_QUALIFICATION', model_release_epoch=time.time())
                    save()
                    break
                exits = list(TRIAL.glob('*/session_exit_code'))
                if process.poll() is not None or exits:
                    raise RuntimeError('worker setup exited before all eight verified setup receipts')
                if time.time() > deadline - 180:
                    raise TimeoutError('insufficient bounded time remains for fresh admission and qualification')
                time.sleep(2)
            process.wait(timeout=max(1, deadline - time.time() + 45))
        except Exception as exc:
            failure = type(exc).__name__ + ': ' + str(exc)
            (TRIAL / 'ABORT').write_text(failure + '\n')
            # Do not signal remote unknown processes; the newly created task
            # groups have their own immutable deadline, including SSH loss.
            try: process.wait(timeout=max(1, deadline-time.time()+45))
            except subprocess.TimeoutExpired: pass
    exits = list(TRIAL.glob('*/session_exit_code'))
    complete_workers = len(exits) == 8
    passed = []
    for p in TRIAL.glob('*/qualification_005/C*.json'):
        receipt = json.loads(p.read_text())
        if receipt.get('status') == 'PASS': passed.append(receipt['candidate'])
    state.update(status='COMPLETE' if complete_workers and 'C0' in passed else 'FAILED',
                 exit_code=process.poll(), failure=failure, finished_epoch=time.time(),
                 elapsed_seconds=time.time()-start, workers_with_terminal_receipts=len(exits),
                 qualified_candidates=sorted(set(passed)))
    # Charge the full reservation when SSH or terminal evidence is uncertain.
    usage = min(16, 32 * state['elapsed_seconds'] / 3600) if complete_workers else 16
    state['actual_chip_hours'] = usage
    save()
    finish(ROOT / 'receipts/trial_budget.json', 'qualification_005', actual_chip_hours=usage,
           terminal_receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), status=state['status'])
    print(json.dumps(state))


if __name__ == '__main__': main()
