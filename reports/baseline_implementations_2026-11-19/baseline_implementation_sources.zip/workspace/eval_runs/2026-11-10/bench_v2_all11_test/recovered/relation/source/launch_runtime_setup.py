"""Stage the pinned runtime on the one explicitly authorized idle slice."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]
NAME='kmh-tpuvm-v5p-16-us-east5-spot-lyy-10291553guz'
ZONE='us-east5-a'


def main():
    lease=json.loads((ROOT/'receipts/shared_assignment.json').read_text())
    proc=Path('/proc')/str(lease['pid'])
    assert lease['tpu_name']==NAME and lease['expires_epoch']>time.time()
    assert proc.exists() and str(ROOT/'source/hold_assignment.py') in (proc/'cmdline').read_bytes().replace(b'\0',b' ').decode()
    package=json.loads((ROOT/'deployment/bundle_v1.json').read_text())
    assert hashlib.sha256(Path(package['archive']).read_bytes()).hexdigest()==package['archive_sha256']
    gate=ROOT/'receipts/runtime_setup_fresh_gate.json'
    subprocess.run(['python3','-B',str(ROOT/'source/prelaunch_gate.py'),'--name',NAME,'--zone',ZONE,
        '--inventory',str(ROOT/'receipts/search_014006/kristine_inventory.log'),
        '--inventory-receipt',str(ROOT/'receipts/search_014006/kristine_inventory_receipt.json'),
        '--assignment',str(ROOT/'receipts/shared_assignment.json'),'--out',str(gate)],check=True)
    qualification=json.loads((ROOT/'receipts/qualification_001_start.json').read_text())
    deadline=datetime.datetime.fromtimestamp(qualification['deadline_epoch'],datetime.timezone.utc).isoformat()
    remote_root='/dev/shm/relationadapter_autoresearch_010427'
    command=shlex.join(['/kmh-nfs-ssd-us-mount/code/xtiange/anaconda3/envs/resnet/bin/python','-B',
        str(ROOT/'source/deadline_exec.py'),'--deadline',deadline,'--seconds','3600',
        '--receipt',remote_root+'/work/setup_deadline.json','--','bash',str(ROOT/'source/bootstrap_remote_v1.sh')])
    argv=['gcloud','compute','tpus','tpu-vm','ssh',NAME,'--project=he-vision-group','--zone='+ZONE,
          '--worker=all','--internal-ip','--ssh-flag=-F','--ssh-flag=/dev/null','--command='+command]
    start=time.time()
    state={'phase':'runtime_setup_and_model_staging','status':'RUNNING','started_epoch':start,
           'deadline_epoch':min(start+3600,qualification['deadline_epoch']),'tpu_name':NAME,'workers':2,
           'physical_chips':8,'bundle_sha256':package['archive_sha256'],'fresh_gate_sha256':hashlib.sha256(gate.read_bytes()).hexdigest()}
    path=ROOT/'receipts/runtime_setup_controller.json'
    path.write_text(json.dumps(state,indent=2)+'\n')
    with (ROOT/'receipts/runtime_setup_transport.log').open('x') as log:
        result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
    state.update(status='COMPLETE' if result.returncode==0 else 'FAILED',exit_code=result.returncode,
                 elapsed_seconds=time.time()-start,finished_epoch=time.time())
    path.write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps(state))
    raise SystemExit(result.returncode)


if __name__=='__main__':main()
