"""Run the unchanged scorer with a fail-closed prohibition on test payload opens.

The published inventory's file existence/size checks remain permitted. This
wrapper does not alter scorer modules, manifests, numerical code, or inputs.
"""
import os
from pathlib import Path
import runpy
import sys


def prohibit_test_payloads(event, args):
    if event not in ('open', 'os.listdir', 'os.scandir') or not args:
        return
    value=args[0]
    if isinstance(value, (str, bytes, os.PathLike)):
        path=Path(os.fsdecode(value)).absolute()
        if 'bench_v2_test' in path.parts:
            raise PermissionError('Benchmark test payload access is prohibited in this validation-only run')


def main():
    target=Path(sys.argv[1]).resolve()
    sys.argv=sys.argv[1:]
    sys.addaudithook(prohibit_test_payloads)
    runpy.run_path(str(target),run_name='__main__')


if __name__=='__main__':main()
