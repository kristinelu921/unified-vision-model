#!/usr/bin/env python3
"""Materialize fresh corrected-V3 units from RelationAdapter result views."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import zlib

import numpy as np
from PIL import Image

import relation_adapter_bench_v2 as R
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from instruction_policy import policy_from_plan

sys.path.insert(0, str(R.LIVE_REPO))
from tools import bench_episode_v1 as BE  # noqa: E402
from tools.score_bench_outputs_v1 import validate_prediction_result  # noqa: E402

PRODUCER_SCHEMA = "relation_adapter_bench_v2_native_p1_corrected_v3_deferred_v2"
PROTOCOL = "bench_v2_PP2_CSA_seed1_AP_FIRST_v1"
RELEASE = "bd08e05f1d0e9dd077db683f4f124ac49a2c45cd0ec5728653bd1ad66cc13792"


def read_rgb(root, desc, where):
    if desc.get("shape") != [256, 256, 3] or desc.get("dtype") != "uint8" or desc.get("mode") != "RGB":
        raise ValueError(f"{where}: descriptor differs")
    path = root / desc["path"]
    if not path.resolve().is_relative_to(root.resolve()) or R.sha256_file(path) != desc["sha256"]:
        raise ValueError(f"{where}: artifact bytes differ")
    with Image.open(path) as image:
        if image.format != "PNG" or image.mode != "RGB" or image.size != (256, 256):
            raise ValueError(f"{where}: PNG contract differs")
        pixels = np.asarray(image, np.uint8).copy()
    if R.sha256_array(pixels) != desc["pixels_sha256"]:
        raise ValueError(f"{where}: pixels differ")
    return pixels


def link(source_root, dest_root, desc, where, target_rel=None):
    read_rgb(source_root, desc, where)
    relative = Path(desc["path"] if target_rel is None else target_rel)
    source, target = source_root / desc["path"], dest_root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() or target.is_symlink():
        raise ValueError(f"{where}: destination exists")
    try: os.link(source, target)
    except OSError: shutil.copy2(source, target)
    result = dict(desc)
    result["path"] = str(relative)
    return result


def load_arrays(pack):
    root = Path(pack["local_dir"])
    records = json.loads((root / "samples.json").read_text())["records"]
    with np.load(root / "samples.npz", allow_pickle=False) as archive:
        images, masks = np.array(archive["images"], copy=True), np.array(archive["masks"], copy=True)
    if images.dtype != np.uint8 or masks.dtype != np.uint8 or images.shape != masks.shape:
        raise ValueError(f"{pack['rel']}: staged arrays differ")
    return records, images, masks


def build_unit(pack, episodes, plan, views_root, units_root):
    source_root, source_path = views_root / pack["slug"], views_root / pack["slug"] / "results.json"
    source_raw = source_path.read_bytes(); view = json.loads(source_raw)
    expected_view_plan = (R.validation_plan_identity(plan)
                          if pack["rel"] == "bench_v2_val" and plan.get("phase") == "test"
                          else plan["plan_identity"])
    if view.get("complete") is not True or view.get("plan_identity") != expected_view_plan:
        raise ValueError(f"{pack['rel']}: source view is not finalized")
    if set(view["episodes"]) != set(pack["expected_episode_keys"]):
        raise ValueError(f"{pack['rel']}: source coverage differs")
    keys = [f"{ep['task']}@q{ep['q']}" for ep in episodes]
    instruction = policy_from_plan(plan)
    run_manifest = {
        "schema": "relation_adapter_bench_v2_native_p1_corrected_v3_run_manifest_v2",
        "corrected_protocol": PROTOCOL, "corrected_release_sha256": RELEASE,
        "data_identity": pack["data_identity"], "episode_keys": keys, "pack_rel": pack["rel"],
        "plan_identity": plan["plan_identity"], "source_view_sha256": hashlib.sha256(source_raw).hexdigest(),
        "generation": {
            "model": "RelationAdapter", "source_commit": R.SOURCE_COMMIT,
            "flux_revision": R.FLUX_REVISION, "adapter_revision": R.ADAPTER_REVISION,
            "siglip_revision": R.SIGLIP_REVISION, "frozen_p": R.FROZEN_P, "native_p": R.NATIVE_P,
            "adapter": "direct same-source P=1 episode", "prompt": instruction['task_prompts'] or instruction['generic_prompt'],
            "instruction_policy": instruction,
            "prompt_status": "Frozen " + instruction['condition'] + "; benchmark adaptation",
            "episode_seed": R.EPISODE_SEED, "model_seed": R.MODEL_SEED,
            "steps": R.STEPS, "guidance_scale": R.GUIDANCE, "relation_scale_alpha": R.ALPHA,
            "dtype": "bfloat16", "readout": R.READOUT,
        },
    }
    run_identity = R.identity(run_manifest)
    final = units_root / pack["slug"]
    if final.exists() or final.is_symlink():
        raise ValueError(f"fresh unit exists: {final}")
    units_root.mkdir(parents=True, exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix=f".{pack['slug']}.tmp.", dir=units_root))
    try:
        records, images, masks = load_arrays(pack)
        rows_by_task = {}
        for i, record in enumerate(records): rows_by_task.setdefault(record["task"], []).append(i)
        output = {}
        for ep in episodes:
            task, q = ep["task"], ep["q"]; key, source_key = f"{task}@q{q}", f"{task}:{q}"
            source_ep, rows = view["episodes"][source_key], rows_by_task[task]
            if rows[q] != ep["query_global"]: raise ValueError(f"{key}: query mapping differs")
            local_of_global = {global_i: local_i for local_i, global_i in enumerate(rows)}
            demo_indices = [local_of_global[i] for i in ep["demo_global"]]
            if demo_indices != ep["demo_indices"] or len(demo_indices) != R.FROZEN_P or q in demo_indices:
                raise ValueError(f"{key}: frozen demo binding differs")
            if ep["native_demo_index"] != demo_indices[0] or ep["native_demo_record"] != ep["demo_records"][0]:
                raise ValueError(f"{key}: native direct-P1 binding differs")
            query_source = str(records[rows[q]].get("source"))
            candidates = [i for i, row in enumerate(rows) if i != q and str(records[row].get("source")) == query_source]
            if any(i not in candidates for i in demo_indices): raise ValueError(f"{key}: demo source differs")
            coded = BE.code_episode([masks[rows[i]] for i in demo_indices] + [masks[rows[q]]], task, ep["cid"])
            artifacts = source_ep["artifacts"]
            input_desc = link(source_root, temp, artifacts["query_input"], key + ".query_input")
            target_desc = link(source_root, temp, artifacts["query_target"], key + ".query_target")
            pred_rel = f"{task}_q{q}/RelationAdapter_real_native_p1_query.png"
            pred_desc = link(source_root, temp, artifacts["prediction"], key + ".prediction", pred_rel)
            if R.sha256_array(images[rows[q]]) != input_desc["pixels_sha256"] or R.sha256_array(coded[-1]) != target_desc["pixels_sha256"]:
                raise ValueError(f"{key}: staged query differs")
            manifest = {
                "schema": "bench_v2_episode_v26", "run_identity": run_identity, "task": task, "q": q,
                "query_record": ep["query_record"], "demo_indices": demo_indices,
                "demo_records": ep["demo_records"], "cid": ep["cid"],
                "p0": R.FROZEN_P, "p_list": R.NATIVE_P, "candidates": candidates,
                "query_input_sha256": input_desc["pixels_sha256"], "query_target_sha256": target_desc["pixels_sha256"],
                "demo_input_sha256": [R.sha256_array(BE.to_chw01(images[rows[i]])) for i in demo_indices],
                "demo_target_sha256": [R.sha256_array(BE.to_chw01(tile)) for tile in coded[:-1]],
                "episode_rng_seed": [R.EPISODE_SEED, zlib.crc32(task.encode()) & 0xFFFF, q, R.FROZEN_P],
                "native_demo_index": demo_indices[0], "native_demo_record": ep["demo_records"][0],
            }
            sampling = dict(source_ep["readouts"][R.READOUT]["real"], score_pending=True)
            output[key] = {
                "task": task, "q": q, "p": R.NATIVE_P, "p0": R.FROZEN_P, "p_list": R.NATIVE_P,
                "cid": ep["cid"], "query_record": ep["query_record"], "query_source": query_source,
                "demo_indices": demo_indices, "demo_records": ep["demo_records"], "candidates": candidates,
                "native_demo_index": demo_indices[0], "native_demo_record": ep["demo_records"][0],
                "data_identity": pack["data_identity"], "data_identity_sha256": pack["data_identity_sha256"],
                "run_identity": run_identity, "episode_manifest": manifest, "episode_identity": R.identity(manifest),
                "prediction_complete": True, "score_complete": False, "complete": False,
                "readouts": {R.READOUT: {"real": sampling}}, "controls": {"copy": {"score_pending": True}},
                "artifacts": {"query_input": input_desc, "query_target": target_desc,
                              "readouts": {R.READOUT: {"real": pred_desc}}},
            }
        producer = {
            "producer_schema": PRODUCER_SCHEMA, "protocol": PROTOCOL,
            "args": {"pack_rel": pack["rel"], "seed": R.EPISODE_SEED, "p_list": R.NATIVE_P,
                     "frozen_p": R.FROZEN_P, "readout": R.READOUT},
            "p": R.NATIVE_P, "p_list": R.NATIVE_P, "data_identity": pack["data_identity"],
            "data_identity_sha256": pack["data_identity_sha256"], "run_manifest": run_manifest,
            "run_identity": run_identity, "expected_episode_keys": keys, "episodes": output,
            "scoring": {"mode": "deferred", "authoritative": False, "metric_contract": "eval_v2"},
            "prediction_complete": True, "score_complete": False, "complete": False,
            "provenance": {"source_view": str(source_path), "source_view_sha256": hashlib.sha256(source_raw).hexdigest(),
                           "plan_identity": plan["plan_identity"], "conversion": PRODUCER_SCHEMA},
        }
        (temp / "results.json").write_text(json.dumps(producer, indent=2, sort_keys=True, allow_nan=False) + "\n")
        validated, digest = validate_prediction_result(temp, expected_data_identity_sha256=pack["data_identity_sha256"], expected_episodes=keys)
        if validated["run_identity"] != run_identity: raise ValueError("validator changed run identity")
        os.replace(temp, final)
        return {"pack_rel": pack["rel"], "unit": str(final), "episodes": len(output),
                "producer_sha256": digest, "run_identity": run_identity}
    finally:
        if temp.exists(): shutil.rmtree(temp)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True); parser.add_argument("--views-root", type=Path, required=True)
    parser.add_argument("--units-root", type=Path, required=True); parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--phase", choices=("val", "all"), default="all")
    parser.add_argument("--expect-total", type=int); args = parser.parse_args()
    plan = R.validate_plan(args.plan); by_pack = {pack["rel"]: [] for pack in plan["packs"]}
    for ep in plan["episodes"]: by_pack[ep["pack_rel"]].append(ep)
    selected = plan["packs"][:1] if args.phase == "val" else plan["packs"]
    rows = [build_unit(pack, by_pack[pack["rel"]], plan, args.views_root, args.units_root) for pack in selected]
    result = {"schema": "relation_adapter_bench_v2_native_p1_corrected_v3_units_manifest_v1",
              "plan_identity": plan["plan_identity"], "producer_schema": PRODUCER_SCHEMA,
              "corrected_release_sha256": RELEASE, "phase": args.phase, "packs": rows,
              "total_episodes": sum(row["episodes"] for row in rows)}
    expected = args.expect_total if args.expect_total is not None else (221 if args.phase == "val" else 17_732)
    if result["total_episodes"] != expected: raise SystemExit("episode total differs")
    if args.manifest.exists() or args.manifest.is_symlink(): raise SystemExit("unit manifest exists")
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"packs": len(rows), "episodes": result["total_episodes"]}, sort_keys=True))


if __name__ == "__main__": main()
