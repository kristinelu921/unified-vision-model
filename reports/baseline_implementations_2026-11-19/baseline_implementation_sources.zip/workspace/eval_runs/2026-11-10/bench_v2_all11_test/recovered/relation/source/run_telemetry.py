"""Aggregate runtime evidence without images, prompts, or per-example scores."""
import json
from pathlib import Path
import resource
import time


def xla_snapshot(metrics, memory_reader):
    out = {'observed_epoch': time.time(), 'process_peak_host_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
           'metrics': {}, 'memory': None, 'device_peak_memory_bytes': None}
    for name in ['CompileTime', 'ExecuteTime', 'TransferToDeviceTime', 'TransferFromDeviceTime']:
        try:
            data = metrics.metric_data(name)
            if data is not None:
                out['metrics'][name] = {'total_samples': data[0], 'accumulator_raw': data[1],
                                        'units': 'runtime native; raw counter, not assumed seconds'}
        except Exception as exc:
            out['metrics'][name] = {'unavailable': type(exc).__name__}
    try:
        out['formatted_time_metrics'] = metrics.short_metrics_report(counter_names=['CachedCompile'],
            metric_names=['CompileTime', 'ExecuteTime', 'TransferToDeviceTime', 'TransferFromDeviceTime'])
    except Exception as exc:
        out['formatted_metrics_unavailable'] = type(exc).__name__
    try:
        memory = memory_reader()
        out['memory'] = {key: int(value) for key, value in dict(memory).items()}
        # Do not label a current usage sample as a peak. Retain an explicit
        # backend peak counter only if the runtime actually exposes one.
        for key in ['peak_bytes_used', 'peak_memory_usage_bytes']:
            if key in memory: out['device_peak_memory_bytes'] = int(memory[key])
    except Exception as exc:
        out['memory_unavailable'] = type(exc).__name__
    return out


def snapshot_delta(before, after):
    result = {}
    for name, value in after.get('metrics', {}).items():
        old = before.get('metrics', {}).get(name)
        if old and 'accumulator_raw' in old and 'accumulator_raw' in value:
            result[name] = {'total_samples': value['total_samples'] - old['total_samples'],
                            'accumulator_raw': value['accumulator_raw'] - old['accumulator_raw'],
                            'units': value['units']}
    return result


def seal_prediction(path, pixels_sha256, ordinal):
    # PNG bytes are hashed mechanically; no inference decision uses predictions.
    import hashlib
    return {'ordinal': ordinal, 'path': Path(path).name,
            'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'pixels_sha256': pixels_sha256, 'bytes': Path(path).stat().st_size}
