"""Bounded CPU profile on synthetic conditioning at the actual layer dimensions.

Only one layer is instantiated. No model weights or benchmark inputs are read.
This measures the suspected repeated projection cost, not end-to-end throughput.
"""
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import time

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source'))
from attention_processor_cached import IPAFluxAttnProcessor2_0


def main():
    torch.set_num_threads(2)
    torch.manual_seed(127)
    results = []
    for dtype in (torch.float32, torch.bfloat16):
        processor = IPAFluxAttnProcessor2_0(3072, 4096, num_tokens=128).to(dtype=dtype).eval()
        relation = torch.randn(2, 128, 4096, dtype=dtype)
        with torch.no_grad():
            processor.relation_kv(relation, 1, 24, 128)  # uncounted CPU warmup, declared
            samples = []
            for _ in range(3):
                start = time.perf_counter()
                for step in range(24):
                    reference = processor.relation_kv(relation, 1, 24, 128)
                reference_seconds = time.perf_counter() - start
                start = time.perf_counter()
                processor.bind_relation_cache(relation, identity='0' * 64, batch_size=1, heads=24, head_dim=128)
                for step in range(24):
                    cached = processor.relation_kv(relation, 1, 24, 128)
                cached_seconds = time.perf_counter() - start
                assert all(torch.equal(a, b) for a, b in zip(reference, cached))
                samples.append({'reference_seconds': reference_seconds, 'cached_seconds_including_prepare': cached_seconds})
                processor.clear_relation_cache()
            ref = statistics.median(x['reference_seconds'] for x in samples)
            opt = statistics.median(x['cached_seconds_including_prepare'] for x in samples)
        results.append({'dtype': str(dtype), 'samples': samples, 'median_reference_seconds': ref,
                        'median_cached_seconds': opt, 'speedup_projection_only': ref / opt,
                        'outputs_exact': True, 'cache_bytes_per_layer': sum(x.numel() * x.element_size() for x in cached),
                        'cache_bytes_all_57_layers': 57 * sum(x.numel() * x.element_size() for x in cached)})
        del processor, relation, cached, reference
        gc.collect()
    receipt = {'schema': 'relationadapter_projection_cpu_profile_v1', 'backend': 'CPU',
               'profile_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'candidate_source_sha256': hashlib.sha256((ROOT / 'source/attention_processor_cached.py').read_bytes()).hexdigest(),
               'threads': 2, 'torch': torch.__version__, 'synthetic_seed': 127,
               'layer_dimensions': {'tokens': 256, 'input': 4096, 'hidden': 3072, 'heads': 24},
               'scope': 'one actual-size adapter layer; no full-model/TPU/end-to-end speed claim',
               'results': results}
    (ROOT / 'receipts/projection_profile.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__': main()
