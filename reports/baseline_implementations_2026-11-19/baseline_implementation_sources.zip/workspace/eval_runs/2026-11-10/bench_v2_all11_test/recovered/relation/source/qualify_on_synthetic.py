"""Full 24-step reference/cached qualification on synthetic inputs only.

Prepared for authorized v5p-16 hardware. Does not read a benchmark pack. A PASS
receipt requires exact outputs on the selected TPU. Partial timing and failure
receipts are retained without qualifying an incomplete candidate.
"""
import argparse
import contextlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys
import time

import numpy as np
from PIL import Image
import torch

from conditioning_scope import prepared_relation
from finite_output import finite_cpu, install_decode_guard, float_digest
from runtime_loader import load_runtime
from instruction_policy import policy, prompt_map_for, select_embeddings
from cache_identity import ConditioningIdentity
from run_target_free import ROOT, load_baseline, sha, hash_value, check_deadline, candidate_source_identity
from target_free_episode import pixels_sha256
from execution_contract import production_environment, runtime_contract, check_official_source, require_node_local_paths, require_authorized_resource, hardware_profile
from run_telemetry import xla_snapshot


def main():
    p = argparse.ArgumentParser()
    for name in ['flux-dir', 'adapter-dir', 'siglip-dir', 'source-dir', 'cache-dir', 'out', 'license-ack']:
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--tpu-name', required=True)
    p.add_argument('--condition', choices=['generic_text','task_text_alpha1'], default='task_text_alpha1')
    p.add_argument('--reference-only', action='store_true')
    args = p.parse_args()
    check_deadline()
    require_authorized_resource(args.tpu_name)
    if os.environ.get('PJRT_DEVICE') != 'TPU':
        raise SystemExit('authorized TPU required')
    require_node_local_paths(args)
    baseline = load_baseline()
    baseline.verify_license_ack(args.license_ack)
    for name, folder in [('FLUX.1-dev', args.flux_dir), ('RelationAdapter', args.adapter_dir), ('siglip-so400m-patch14-384', args.siglip_dir)]:
        baseline.verify_asset_tree(folder, baseline.ASSET_MANIFESTS[name])
    environment = production_environment()
    execution = runtime_contract(environment, args.condition)
    runtime_identity = hash_value(execution)
    check_official_source(args.source_dir)
    import torch_xla
    import torch_xla.core.xla_model as xm
    import torch_xla.distributed.spmd as xs
    import torch_xla.runtime as xr
    import torch_xla.debug.metrics as metrics
    import attention_processor_cached
    sys.modules['attention_processor'] = attention_processor_cached
    xr.initialize_cache(str(args.cache_dir / runtime_identity), readonly=False)
    xr.use_spmd()
    count, local = int(xr.global_runtime_device_count()), int(xr.addressable_runtime_device_count())
    hardware = hardware_profile()
    if xr.device_type() != 'TPU' or (count, local) != (hardware['global_devices'], hardware['addressable_devices']):
        raise SystemExit('declared hardware topology required')
    mesh = xs.Mesh(np.arange(count), (count,), ('fsdp',))
    xs.set_global_mesh(mesh)
    device = xm.xla_device()
    writer = xr.process_index() == 0
    worker_receipts = args.out.parent / ('telemetry_' + args.out.name)
    worker_receipts.mkdir(parents=True, exist_ok=True)
    if writer: args.out.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    prompt_map = prompt_map_for(args.condition)
    runtime = load_runtime(baseline, args, device, mesh, task_prompts=prompt_map)
    report_nonfinite = lambda detail: baseline.atomic_json(worker_receipts / f"nonfinite_worker_{xr.process_index()}.json", detail)
    finite_guard = install_decode_guard(runtime["pipe"].vae, report_nonfinite)
    xm.mark_step(wait=True)
    loading = time.monotonic() - start
    processors = [m for m in runtime['pipe'].transformer.modules() if hasattr(m, 'bind_relation_cache')]
    if len(processors) != 57: raise SystemExit('unexpected adapter layout')
    ref_spec = importlib.util.spec_from_file_location('official_reference_attention', args.source_dir / 'attention_processor.py')
    reference_module = importlib.util.module_from_spec(ref_spec)
    ref_spec.loader.exec_module(reference_module)
    reference_class = reference_module.IPAFluxAttnProcessor2_0
    cached_class = attention_processor_cached.IPAFluxAttnProcessor2_0
    rng = np.random.default_rng(91521)
    durations = {'C0': [], 'C0_repeat': [], 'C1': []}
    exact, repeat_exact, raw_exact, raw_repeat_exact = [], [], [], []
    def save_progress():
        progress = {
            'status': 'INCOMPLETE_NOT_QUALIFIED', 'synthetic_only': True,
            'worker_index': xr.process_index(), 'runtime_identity': runtime_identity,
            'completed_fixture_comparisons': len(exact), 'seconds': durations,
            'C1_reference_exact_so_far': exact, 'reference_repeat_exact_so_far': repeat_exact,
            'wall_seconds_worker': time.monotonic() - start,
            'telemetry': xla_snapshot(metrics, lambda: xm.get_memory_info(device)),
        }
        baseline.atomic_json(worker_receipts / f'progress_worker_{xr.process_index()}.json', progress)
    for fixture in range(4):
        task = ['relative_depth','surface_normals','edge_detection','inpainting'][fixture]
        active_prompt, active_pooled = select_embeddings(runtime, args.condition, task)
        check_deadline()
        if time.monotonic() - start >= hardware['max_accelerator_seconds_per_trial']:
            raise TimeoutError('qualification hardware budget exhausted')
        before = rng.integers(0, 256, (256, 256, 3), dtype=np.uint8)
        after = np.flip(before, axis=1).copy()
        query = rng.integers(0, 256, (256, 256, 3), dtype=np.uint8)
        identity = ConditioningIdentity(hash_value(baseline.ASSET_MANIFESTS), sha(ROOT / 'official/source_manifest.json'),
            candidate_source_identity(), hash_value(environment), hash_value(execution['config']),
            sha(ROOT / 'source/baseline_archive/relation_adapter_bench_v2.py'), hash_value({'policy': policy(args.condition), 'task': task, 'tokens': 512}),
            'TPU-' + hardware['accelerator'] + '/torch-xla2.8/bfloat16', (pixels_sha256(before),), (pixels_sha256(after),), pixels_sha256(query), 1000)
        outputs = []
        # Alternate order to reduce systematic warm-cache order effects.
        order = ['C0', 'C1', 'C0_repeat'] if fixture % 2 == 0 else ['C1', 'C0', 'C0_repeat']
        if args.reference_only: order = ['C0', 'C0_repeat']
        by_candidate = {}
        raw_by_candidate = {}
        for candidate in order:
            # Same parameters, real official __call__ for reference; no copied
            # approximation of the attention algorithm is used on hardware.
            for processor in processors:
                processor.__class__ = cached_class if candidate == 'C1' else reference_class
            tick = time.monotonic()
            relation = baseline.relation_embedding(runtime, Image.fromarray(before), Image.fromarray(after), device)
            scope = prepared_relation(processors, relation, identity, heads=24, head_dim=128) if candidate == 'C1' else contextlib.nullcontext(relation)
            with scope as conditioning:
                torch_xla.manual_seed(1000, device=device)
                with torch.no_grad():
                    output = runtime['pipe'](prompt=None, prompt_embeds=active_prompt,
                        pooled_prompt_embeds=active_pooled, image_emb=conditioning,
                        condition_image=Image.fromarray(query), height=256, width=256,
                        guidance_scale=3.5, num_inference_steps=24, generator=None, output_type='pt').images
                xm.mark_step()
                raw = finite_cpu(output[0], stage='postprocessed_image', report=report_nonfinite)
                raw_by_candidate[candidate] = float_digest(raw)
                by_candidate[candidate] = (raw.clamp(0, 1) * 255).round().to(torch.uint8).numpy()
            durations[candidate].append(time.monotonic() - tick)
            save_progress()
        for processor in processors: processor.__class__ = cached_class
        exact.append(None if args.reference_only else np.array_equal(by_candidate['C0'], by_candidate['C1']))
        repeat_exact.append(np.array_equal(by_candidate['C0'], by_candidate['C0_repeat']))
        raw_repeat_exact.append(raw_by_candidate['C0'] == raw_by_candidate['C0_repeat'])
        raw_exact.append(None if args.reference_only else raw_by_candidate['C0'] == raw_by_candidate['C1'])
        save_progress()
    for candidate in (['C0'] if args.reference_only else ['C0', 'C1']):
        passed = all(repeat_exact) and all(raw_repeat_exact) and finite_guard['checked_decodes'] >= 8 and (candidate == 'C0' or (all(exact) and all(raw_exact)))
        receipt = {'instruction_policy':policy(args.condition), 'condition':args.condition, 'schema': 'relationadapter_same_backend_qualification_v2', 'candidate': candidate,
                   'status': 'PASS' if passed else 'FAIL', 'all_outputs_exact': passed, 'fixtures': len(exact),
                   'synthetic_only': True, 'synthetic_seed': 91521, 'tpu_name': args.tpu_name, 'hardware': hardware,
                   'source_identity': candidate_source_identity(), 'environment': environment,
                   'runtime_identity': runtime_identity, 'execution_contract': execution,
                   'reference_repeat_exact': all(repeat_exact), 'raw_reference_repeat_exact': all(raw_repeat_exact),
                   'raw_C1_reference_exact': None if args.reference_only else all(raw_exact),
                   'finite_output_guard': finite_guard, 'block_wrapping': runtime['block_wrapping'], 'C1_reference_exact': None if args.reference_only else all(exact), 'optimization_tested': not args.reference_only,
                   'model_loading_seconds': loading, 'cold_first_fixture_seconds': {k: v[0] for k, v in durations.items() if v},
                   'warm_seconds': {k: v[1:] for k, v in durations.items()},
                   'wall_seconds': time.monotonic() - start, 'cuda_parity': False,
                   'telemetry_final': xla_snapshot(metrics, lambda: xm.get_memory_info(device)),
                   'C1_speed_gate_passed': False if args.reference_only else statistics.median(durations['C1'][1:]) <= 0.95 * statistics.median(durations['C0'][1:])}
        if writer: baseline.atomic_json(args.out / (candidate + '.json'), receipt)
    baseline.atomic_json(worker_receipts / f'worker_{xr.process_index()}.json', {
        'worker_index': xr.process_index(), 'global_devices': count, 'addressable_devices': local,
        'runtime_identity': runtime_identity, 'wall_seconds_worker': time.monotonic() - start,
        'final': xla_snapshot(metrics, lambda: xm.get_memory_info(device))})
    if not all(repeat_exact) or not all(raw_repeat_exact): raise SystemExit('reference is not repeatable; neither candidate qualified')
    if not args.reference_only and (not all(exact) or not all(raw_exact)): raise SystemExit('C1 equality failed; retain the independently qualified C0 reference')


if __name__ == '__main__': main()
