"""Bounded read-only watch of the one currently authorized, occupied TPU.

No launch, claim, cleanup, provisioning, or signal capability. Notify only on
actionable availability or a terminal failure; unchanged occupancy stays quiet.
"""
import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import time
from watch_capacity import notify

ROOT=Path(__file__).resolve().parents[1]
NAME='kmh-tpuvm-v5p-16-us-east5-spot-lyy-10291553guz'
ZONE='us-east5-a'
DEADLINE=1793408667

def main():
    out=ROOT/'receipts/authorized_resource_watch'
    out.mkdir(exist_ok=False)
    state={'status':'RUNNING_READ_ONLY','pid':os.getpid(),'resource':NAME,'zone':ZONE,
        'poll_seconds':300,'deadline_epoch':DEADLINE,'launches_workloads':False}
    (out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
    while time.time()<DEADLINE-120:
        stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        try:
            result=subprocess.run(['gcloud','compute','tpus','tpu-vm','describe',NAME,
                '--project=he-vision-group','--zone='+ZONE,
                '--format=json(name,state,health,acceleratorType,acceleratorConfig,schedulingConfig)'],
                capture_output=True,text=True,timeout=50)
            if result.returncode: raise RuntimeError('describe failed')
            cloud=json.loads(result.stdout)
            (out/(stamp+'_describe.json')).write_text(result.stdout)
            state.update(checked_utc=stamp,cloud_state=cloud.get('state'),cloud_health=cloud.get('health'))
            if cloud.get('state')=='READY' and cloud.get('health')=='HEALTHY':
                probe=(ROOT/'receipts/search_014006/readonly_probe.sh').read_text()
                check=subprocess.run(['gcloud','compute','tpus','tpu-vm','ssh',NAME,
                    '--project=he-vision-group','--zone='+ZONE,'--worker=all','--internal-ip',
                    '--ssh-flag=-F','--ssh-flag=/dev/null','--ssh-flag=-o','--ssh-flag=ConnectTimeout=12',
                    '--command='+probe],capture_output=True,text=True,timeout=100)
                raw=check.stdout+check.stderr
                (out/(stamp+'_occupancy.log')).write_text(raw)
                workers=set(re.findall(r'^AVAILABLE worker=(\S+)',raw,re.M))
                available=(check.returncode==0 and len(workers)==2 and
                    not any(x in raw for x in ['UNKNOWN','OCCUPIED','STALE_LOCK','RECLAIMABLE']))
                state['occupancy']='AVAILABLE' if available else 'UNAVAILABLE_OR_UNKNOWN'
                if available:
                    state['notification']=notify('RelationAdapter / relationadapter_autoresearch_010427: '
                        'the already-authorized TPU '+NAME+' now has both workers idle. '
                        'Recommended next step: resume the prepared continuous-session synthetic qualification '
                        'after a fresh assignment and occupancy check. No new authorization is needed; '
                        'this read-only watcher has not started a workload.')
                    state['status']='AVAILABLE_NOTIFIED_NO_WORKLOAD_STARTED'
                    break
            if cloud.get('state') in ['DELETING','TERMINATED']:
                state['notification']=notify('RelationAdapter / relationadapter_autoresearch_010427: '
                    'authorized TPU '+NAME+' is '+cloud['state']+'. Full validation remains blocked. '
                    'Recommended next step: find another existing compatible authorized TPU; do not provision or disturb a run.')
                state['status']='RESOURCE_UNAVAILABLE_TERMINAL'
                break
            state.pop('error_type',None)
        except Exception as exc:
            state.update(checked_utc=stamp,error_type=type(exc).__name__,occupancy='UNKNOWN')
        (out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
        time.sleep(max(0,min(300,DEADLINE-time.time()-120)))
    if state['status']=='RUNNING_READ_ONLY': state['status']='DEADLINE_REACHED'
    state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out/'status.json').write_text(json.dumps(state,indent=2)+'\n')

if __name__=='__main__': main()
