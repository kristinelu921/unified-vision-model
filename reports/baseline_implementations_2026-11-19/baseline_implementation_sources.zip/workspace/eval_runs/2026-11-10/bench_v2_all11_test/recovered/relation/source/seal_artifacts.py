"""Hash this isolated snapshot without decoding data or inspecting examples."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={'manifests/artifacts.json','manifests/SHA256SUMS','manifests/verification.log',
          'receipts/manifest_verification.log'}


def main():
    active=[]
    for path in (ROOT/'receipts').glob('qualification_*_controller.json'):
        state=json.loads(path.read_text())
        if state.get('status') not in ['COMPLETE','FAILED','BLOCKED_BEFORE_REMOTE_START_FOREIGN_OCCUPANCY']:
            active.append(state.get('trial_id',path.stem.removesuffix('_controller')))
    records=[];skipped=[]
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:continue
        name=str(path.relative_to(ROOT))
        if (name in EXCLUDED or any(part in name for part in ['/capacity_monitor/','/authorized_resource_watch/'])
            or name in ['receipts/shared_assignment.json','receipts/validation_continuation.json']
            or name.startswith('receipts/validation_continuation_')
            or any(name.startswith('receipts/'+trial) for trial in active)
            or name.startswith('trials/')):
            skipped.append(name);continue
        if name.startswith('cache_snapshots/') and '/files/' in name:
            skipped.append(name);continue  # Each snapshot has its own complete SHA256SUMS.
        h=hashlib.sha256()
        with path.open('rb') as stream:
            for data in iter(lambda:stream.read(8<<20),b''):h.update(data)
        records.append({'path':name,'sha256':h.hexdigest(),'bytes':path.stat().st_size})
    manifest={'schema':'relationadapter_artifact_manifest_v1',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files':records,'excluded_mutable_or_self_files':skipped,
        'note':'Point-in-time snapshot; mutable trial artifacts are separately sealed by their terminal receipts.'}
    (ROOT/'manifests/artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/'manifests/SHA256SUMS').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in records))
    print(json.dumps({'sealed_files':len(records),'excluded':len(skipped)}))


if __name__=='__main__':main()
