"""Build aggregate-only audit artifacts; no example pixels or scores are opened."""
from pathlib import Path
import csv
import hashlib
import json
import statistics

ROOT = Path(__file__).resolve().parents[1]
OFFICIAL = 'https://github.com/gy8888/RelationAdapter/blob/0ebdebcf5697f5881b5bf3d2fd58d2938733a4e7/'
PAPER = 'https://papers.nips.cc/paper_files/paper/2025/file/8c3e38ce55a0fa44bc325bc6fdb7f4e5-Paper-Conference.pdf'


def read(path): return json.loads((ROOT / path).read_text())
def write(path, value): (ROOT / path).write_text(json.dumps(value, indent=2) + '\n')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    baseline = read('audit/live_relationadapter-bench-v2-validation-scores.json')
    identity = read('audit/baseline_identity.json')
    results = read('source/baseline_receipts/results.json')
    seconds = [ep['readouts']['RelationAdapter@native_p1']['real']['seconds'] for ep in results['episodes'].values()]
    assert len(seconds) == 221 and len(baseline['rows']) == 13 and all(x['n'] == 17 for x in baseline['rows'])
    budget = read('receipts/trial_budget.json')
    accounted_chip_hours = sum(x.get('actual_chip_hours', x['reserved_chip_hours']) for x in budget['trials'].values())
    setup = read('receipts/runtime_setup_controller.json')
    aggregate_timing = {'kind': 'archived_inference_call_aggregates_only', 'episodes': 221,
        'summed_inference_seconds': sum(seconds), 'mean_inference_seconds': statistics.mean(seconds),
        'median_inference_seconds': statistics.median(seconds), 'cold_start_seconds': None,
        'compilation_seconds': None, 'scoring_seconds': None, 'end_to_end_seconds': None,
        'peak_memory': None, 'total_chip_hours': None,
        'hardware': 'one v5p-16 slice; 2 workers; 8 runtime devices total, 4 per worker',
        'one_hour_target_met': 'not established', 'new_accelerator_chip_hours': accounted_chip_hours,
        'chip_hour_accounting': 'Completed attempts use verified resource wall time; unfinished or uncertain attempts retain their full reservations. Current model status is in the attempt controller receipt.',
        'initial_two_worker_setup_seconds': setup['elapsed_seconds'],
        'initial_setup_result': 'Both workers verified full weight trees; node-local shared-memory staging disappeared after logout before model launch.',
        'frozen_scorer_constructor_seconds': read('receipts/scorer_preflight.json')['elapsed_seconds'],
        'zero_overhead_average_seconds_budget': 3600 / 221,
        'remaining_seconds_if_archived_inference_sum_reproduced': 3600 - sum(seconds),
        'additional_capacity_required': 'cannot establish without cold staging/loading/compile/scoring and same-backend profile',
        'warning': 'Sum of recorded calls is not a complete wall-clock measurement; no precomputed predictions count as a fresh run.'}
    if (ROOT/'receipts/qualification_004_controller.json').exists():
        cold=read('receipts/qualification_004_controller.json')
        aggregate_timing['cold_qualification_attempt']={key:cold.get(key) for key in
            ['status','elapsed_seconds','staging_seconds','actual_chip_hours','qualified_candidates']}
        aggregate_timing['cold_phase_limitation']='No complete synthetic output was recorded; model loading and first-output compilation cannot be separately timed from these partial receipts.'
    aggregate_timing['original_24_hour_cutoff_lifted']=(ROOT/'configs/user_time_extension.json').exists()
    if (ROOT/'receipts/scoring_asset_stage.json').exists():
        aggregate_timing['cold_cpu_scoring_asset_stage_seconds']=read('receipts/scoring_asset_stage.json')['elapsed_seconds']
    write('reports/timing_evidence.json', aggregate_timing)
    audit = [
        {'item': 'official provenance', 'finding': 'Author-linked paper and repository agree on method identity. All four executable official file hashes match the frozen plan. Pin the original arXiv v1 and the extended NeurIPS 2025 paper separately.',
         'evidence': [PAPER + '#page=1', 'https://arxiv.org/abs/2506.02528v1', OFFICIAL + 'README.md'], 'status': 'verified'},
        {'item': 'checkpoint/backbones', 'finding': 'Adapter revision 7f65ecd6c7718c6de92782dade849a4872aa986a requires BOTH ip_adapter-100000.bin and pytorch_lora_weights.safetensors; FLUX.1-dev revision 3de623fc3c33e44ffbe2bad470d0f45bccf2eb21; SigLIP revision 9fdffc58afc957d1a03a25b10dba0329ab15c2a3. LoRA is fused once. Weight manifest bytes verified; full weights were not transferred or rehashed this session.',
         'evidence': [OFFICIAL + 'infer_single.py#L211-L249', 'https://huggingface.co/handsomeWilliam/RelationAdapter/tree/7f65ecd6c7718c6de92782dade849a4872aa986a'], 'status': 'full asset verification completed on both initial workers; staged copies later lost'},
        {'item': 'demonstration routing/order', 'finding': 'One same-source demonstration, input then output. Two SigLIP pooled embeddings each pass through the 1152->2304->4096x128 MLP plus LayerNorm. Concatenation on dimension 0 is reshaped into 256 reference tokens for batch 1. Do not naively batch queries or claim support for more demo pairs.',
         'evidence': [OFFICIAL + 'infer_single.py#L56-L74', OFFICIAL + 'infer_single.py#L143-L197', OFFICIAL + 'attention_processor.py#L54-L74'], 'status': 'preserved'},
        {'item': 'preprocessing/resolution', 'finding': 'RGB demonstrations are white-padded to the nearest supported aspect ratio, bilinearly resized to long side 512, then passed through pinned SigLIP processor (384). Query size is the supplied 256x256 image; released code uses query native dimensions. No automatic upscale or resolution reduction is introduced.',
         'evidence': [OFFICIAL + 'infer_single.py#L18-L57', OFFICIAL + 'infer_single.py#L251-L271', PAPER + '#page=6'], 'status': 'exact synthetic preprocessing equality passed'},
        {'item': 'query conditioning/mask/output', 'finding': 'Query image is VAE-encoded with sampling, concatenated after noise tokens, and position encodings are cloned. Each scheduler step restores the condition token half via the fixed mask. Only the predicted first half is decoded. No raster grid or layout instruction belongs to this RelationAdapter condition.',
         'evidence': [OFFICIAL + 'src/pipeline_pe_clone.py#L487-L540', OFFICIAL + 'src/pipeline_pe_clone.py#L684-L729', PAPER + '#page=5'], 'status': 'preserved; no VAE latent cache'},
        {'item': 'text condition', 'finding': 'Full validated row uses Apply the demonstrated image transformation. Paper uses directional editing instructions without detailed content descriptions; the released demo has a concrete editing instruction. Generic text is a named benchmark adaptation. T1 templates are independently authored from public task definitions, not official supplied templates. They remain unrun and must not be called a corrected score.',
         'evidence': [PAPER + '#page=6', PAPER + '#page=21', OFFICIAL + 'infer_single.py#L227-L231'], 'status': 'explicit difference; quality search gated'},
        {'item': 'sampling/guidance/strength/seeds', 'finding': '24 denoising steps, guidance 3.5, alpha=1, seed 1000, one output match released defaults and Appendix A.2. Episode draw uses [42, crc32(task)&0xffff, q, 1]; frozen demo indices are replayed unchanged. CID is 0 for all 221 episodes. Model RNG is reset per query after deterministic relation encoding. CUDA and XLA RNG streams are not assumed equivalent.',
         'evidence': [PAPER + '#page=21', OFFICIAL + 'infer_single.py#L160-L197'], 'status': 'preserved; no CUDA parity claim'},
        {'item': 'precision/environment', 'finding': 'Official model path uses bfloat16 with torch 2.5.1+cu124 suggested in requirements. Baseline uses torch/XLA 2.8, diffusers 0.32.2, transformers 4.44.0. CPU tests use a separately recorded environment. Cross-backend parity is unestablished.',
         'evidence': [OFFICIAL + 'requirements.txt', OFFICIAL + 'infer_single.py#L233-L242'], 'status': 'backend difference disclosed'},
        {'item': 'attention semantics/strength ablations', 'finding': '57 adapter processors add alpha times visual cross-attention using normalized K and unnormalized V. Appendix D documents alpha in {0.5,1,2}. Its in-context architecture ablation removes the adapter and changes inputs; that is not a drop-in alpha=0 baseline improvement and is excluded.',
         'evidence': [OFFICIAL + 'attention_processor.py#L54-L139', PAPER + '#page=23', PAPER + '#page=21'], 'status': 'finite family declared; no retraining'},
        {'item': 'inference/target boundary', 'finding': 'Archived inference reconstructs and hashes the query target before prediction, although predict() receives only before/after/query. New dataset-side export codes demonstrations alone; inference accepts only those inputs. Separate scorer reconstructs the query target after inference. CID0 demo-first equivalence passed synthetic palette tests; no validation examples inspected.',
         'evidence': ['source/baseline_archive/relation_adapter_bench_v2.py:308', 'source/target_free_episode.py', 'source/prepare_inference_inputs.py', 'source/prepare_scoring_view.py'], 'status': 'implemented and CPU verified; hardware run pending'},
        {'item': 'optimization', 'finding': 'Official attention recomputes unchanged demonstration K/V projections at every denoising step. C1 prepares them once per episode, preserves all operations and ordering, validates numerical dependencies, and clears on exit/failure. Do not cache stochastic VAE latents, adapted states, final predictions, or another query\'s conditioning.',
         'evidence': [OFFICIAL + 'attention_processor.py#L54-L74', 'source/attention_processor_cached.py', 'source/conditioning_scope.py'], 'status': 'exact CPU synthetic outputs; full TPU qualification pending'},
        {'item': 'frozen scoring', 'finding': 'Preserve corrected-v3 release bd08e05f1d0e9dd077db683f4f124ac49a2c45cd0ec5728653bd1ad66cc13792, metric identity e0c046fb2fcb150092e8333831f9bb75671c999c10a3f302b97d6054d88d2d8f, PP2/CSA seed1 AP_FIRST. All 128 recorded source hashes match, including shared scorer; none changed. Host-specific provenance may change a newly admitted runtime identity; it must be disclosed and the frozen release/source/numerical contract retained.',
         'evidence': ['source/baseline_receipts/score_manifest.json', 'manifests/scorer_source_verification.json'], 'status': 'verified metadata; new scoring not run'}]
    audit[1]['finding'] = audit[1]['finding'].replace('Weight manifest bytes verified; full weights were not transferred or rehashed this session.', 'Both authorized TPU workers transferred the full region-local weight trees and passed exact file-set/SHA verification. Saved transport logs retain successful completion; shared-memory files disappeared after session logout, before model execution.')
    audit[-1]['finding'] += ' The host system libraries had changed; eight exact certified libraries were staged and mounted only in a private child namespace. The unchanged scorer constructor and LPIPS preload passed in 7.663 seconds. Original release/build/admission pins remain intact; no new replay, test access, or scoring occurred.'
    audit[-1]['status'] = 'frozen constructor admission passed; validation scoring pending'
    if (ROOT/'receipts/full_backend_preflight.json').exists():
        audit[-1]['finding'] += (' Full backend admission also passed. It preserves published-inventory '
            'existence/size checks through read-only private mounts of existing test sidecars, while an audit '
            'guard prohibits test payload opens and enumeration. No test payload was copied, hashed, decoded, or scored.')
        audit[-1]['status']='full frozen backend admission passed with test-open guard; validation scoring pending'
    write('reports/fidelity_audit.json', audit)
    variants = [
        {'trial_id': 'B0', 'label': 'Preserved validated generic-text XLA baseline', 'status': 'VALIDATED_ARCHIVE', 'episodes': 221, 'rows': baseline['rows'], 'edge_pooled': baseline['edge_pooled'], 'fresh_this_session': False},
        {'trial_id': 'C0', 'label': 'Target-isolated generic-text reproduction', 'status': 'CPU_TESTED_TPU_BLOCKED', 'episodes': 0, 'rows': None},
        {'trial_id': 'C1', 'label': 'Target-isolated reproduction with per-episode K/V reuse', 'status': 'CPU_TESTED_TPU_BLOCKED', 'episodes': 0, 'rows': None},
        *[{'trial_id': k, 'label': 'Directional task-text/strength ablation', 'status': 'NOT_RUN_DEVELOPMENT_AND_TPU_GATES_CLOSED', 'episodes': 0, 'rows': None} for k in ['T1', 'T05', 'T2']]]
    comparison = {'schema': 'relationadapter_autoresearch_display_v1', 'publication': 'separate draft; do not replace live rows',
                  'run_id': ROOT.name, 'pack_id': '8e139f91b083e0ae73b2ed81d8e235460ac2f37d', 'supervision_version': 6,
                  'split': 'validation', 'tasks': 13, 'queries_per_task': 17, 'native_demonstrations': 1,
                  'metric_protocol': baseline['protocol'], 'baseline_metric_identity_sha256': baseline['metric_identity_sha256'],
                  'variants': variants, 'new_quality_improvement': None, 'new_full_validation_runs': 0,
                  'generalization_claim': False, 'validation_tuned': False}
    hardware_path = ROOT / 'configs/hardware_profile.json'
    if hardware_path.exists():
        comparison['prepared_candidate_hardware'] = read('configs/hardware_profile.json')
        comparison['cross_topology_parity_claimed'] = False
        for variant in variants:
            if variant['trial_id'] in ['C0','C1']:
                variant['label'] += ' — prepared v5p-64 hardware port'
    write('reports/bench_v2_display_data.json', comparison)
    with (ROOT / 'reports/baseline_aggregate.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(baseline['rows'][0])); w.writeheader(); w.writerows(baseline['rows'])
    tests = read('receipts/synthetic_tests.json')
    handoff = read('receipts/handoff_runtime_tests.json')
    profile = read('receipts/projection_profile.json')
    capacity = read('receipts/capacity_monitor/status.json')
    inventory = (ROOT / capacity['inventory_file']).read_text().splitlines()
    resource_states = []
    for line in inventory:
        fields = line.split('\t')
        if len(fields) == 5 and 'kristine' in fields[0].lower():
            resource_states.append(fields[0] + ': ' + fields[2] + ' (' + fields[4] + ')')
    capacity_line = ('Latest completed read-only reconciler at ' + capacity['checked_utc']
        + ' returned AVAILABLE: ' + str(capacity['final_available']) + '. Observed resources: '
        + '; '.join(resource_states) + '. No resource was claimed, provisioned, restarted, stopped, or used. '
        + 'Active workloads are untouched. Historical non-kristine authorization was not reused. '
        + 'Prepared workers require compatible v5p-16 topology and fresh same-resource qualification.')
    assignment_note = ''
    conflict_path = ROOT / 'audit/assignment_conflict.json'
    if conflict_path.exists():
        conflict = json.loads(conflict_path.read_text())
        assignment_note = ('Assignment check at ' + conflict['checked_utc'] + ': the available v6e-8 '
            + 'is not available to RelationAdapter. PromptDiffusion records an exclusive slot until '
            + '2026-10-30 02:33:39 UTC, while GenLV also records a claim for the same resource. '
            + 'The conflict was reported through an accepted ntfy notification. No RelationAdapter '
            + 'staging or workload was started there. This candidate is withdrawn from launch selection '
            + 'until assignments are reconciled. A future v6e-8 run also requires a separately declared '
            + 'hardware port and synthetic qualification; the current prepared worker is v5p-16 only.')
    launch_path = ROOT / 'receipts/launch_request.json'
    launch_note = ''
    result_status = 'Full-model work is blocked by the absence of eligible, exclusively assigned TPU capacity.'
    if launch_path.exists():
        launch = json.loads(launch_path.read_text())
        launch_note = ('Alternative found at ' + launch['checked_utc'] + ': ' + launch['resource']
            + ' in ' + launch['zone'] + ', READY/HEALTHY Spot v5p-16 with both workers AVAILABLE. '
            + 'It matches the prepared baseline topology and region. No competing assignment was '
            + 'found in the local assignment/request scan. It remains unclaimed and unreserved; '
            + 'non-kristine named-resource authorization is required before remote changes. '
            + 'The request was delivered through ntfy. Fresh assignment and occupancy checks remain '
            + 'mandatory immediately before launch. See receipts/launch_request.json.')
        result_status = 'A matching idle TPU has been identified; full-model work awaits exact-resource authorization.'
    if (ROOT / 'configs/resource_authorization.json').exists():
        launch_note = ('The user explicitly authorized kmh-tpuvm-v5p-16-us-east5-spot-lyy-10291553guz. '
            'Both workers passed fresh gates and setup completed in 221.065 seconds. The staged /dev/shm '
            'files disappeared after logout; unchanged boot times and default RemoveIPC with Linger=no '
            'suggest login cleanup. A continuous-session recovery is prepared. Its fresh occupancy '
            'gate found kaiminghe-owned world27b workers on both TPU hosts and refused to start. '
            'No foreign process or file was modified. Our local coordination lock was released. '
            'The three other READY v5p-16 slices were also occupied; the new kristine v6e-16 '
            'was already DELETING on exact recheck. There is no currently admitted launch resource.')
        result_status = 'Full-model work is blocked by foreign occupancy on the authorized TPU.'
        capacity_line = 'Replacement checks are saved in receipts/replacement_*.json and *.log. Resource readiness and local assignment records are observations, not exclusive cloud reservations.'
    if launch_path.exists() and launch.get('hardware', {}).get('accelerator') == 'v5p-64':
        launch_note += (' A subsequent user-requested non-kristine sweep found four idle v5p-64 slices. '
            'The recommended resource is ' + launch['resource'] + ' in us-east5-a, READY/HEALTHY Spot, '
            'topology 2x4x4; all eight workers passed the read-only occupancy check. No competing '
            'local assignment was found. The local port requires 32 global devices and four local '
            'devices, seals that profile into runtime/cache identities, and keeps the existing '
            '16-chip-hour per-trial limit by allowing at most 1800 accelerator seconds per trial. '
            'Its qualification must independently establish exact C0 repeatability and C1 equality; '
            'cross-topology equality with archived v5p-16 predictions is not claimed. The new ID '
            'is not yet authorized. See configs/v5p64_execution_amendment.json.')
        result_status = 'A larger idle non-kristine TPU has been identified; its exact-resource authorization is pending.'
        capacity_line = 'The read-only metadata sweep covered 102 resources across six zones. Occupancy checks of four READY/HEALTHY v5p-64 candidates passed all eight workers on each. Raw records are in receipts/non_kristine_search_0207; no remote files, processes, or resource state were changed by that sweep.'
    active_label='qualification_005' if (ROOT/'receipts/qualification_005_controller.json').exists() else 'qualification_004'
    active_path=ROOT/'receipts'/(active_label+'_controller.json')
    model_workers=len(list((ROOT/'receipts'/active_label).glob('*/model_start_epoch')))
    if active_path.exists():
        active=json.loads(active_path.read_text())
        result_status='Current authorized v5p-64 attempt '+active_label+': '+active['status']+'.'
        launch_note=('The user directly authorized '+active['resource']+'. All eight workers passed the fresh gate. '
            'Attempt 003 failed at shared receipt-directory creation before staging: each worker maps kristinelu '
            'to a different numeric UID. Attempts 004 and 005 keep execution under the login identity and use workspace '
            'UID 2013 only for saving this run\'s own receipts. Its continuous sessions have an absolute '
            '1800-second staging-and-compute limit and a second all-worker occupancy barrier before model start. '
            'Current status: '+active['status']+'; workers with a model-start marker: '+str(model_workers)+'.')
        result_status+=' No complete new validation score is available.'
        for variant in variants:
            if variant['trial_id'] in ['C0','C1']:variant['status']='QUALIFICATION_'+active['status']
        comparison['current_execution_status']=active['status']
        comparison['original_24_hour_cutoff_lifted']=(ROOT/'configs/user_time_extension.json').exists()
        write('reports/bench_v2_display_data.json',comparison)
        if active_label=='qualification_005':
            launch_note+=(' The user explicitly approved the fifth total recorded attempt. It restores only the '
                '111 verified executable-cache files, checks their runtime and transfer hashes, and retains '
                'the same scientific source, candidate family, correctness gates, and compute caps.')
            aggregate_timing['warm_qualification_attempt']={key:active.get(key) for key in
                ['status','elapsed_seconds','staging_seconds','actual_chip_hours','qualified_candidates']}
            write('reports/timing_evidence.json',aggregate_timing)
    if (ROOT/'receipts/warm_retry_approval_block.json').exists():
        block=read('receipts/warm_retry_approval_block.json')
        if block.get('user_approval')=='PENDING':
            result_status=('The cold attempt timed out without a completed synthetic output. Automatic approval '
                'review blocked the prepared warm retry under the original attempt-count cap; explicit approval '
                'for five total recorded attempts is pending. No model is running.')
            launch_note+=(' The warm retry restores a recovered subset of 111 verified executable files '
                '(38,867,474,588 bytes across eight workers). Every restored file and runtime identity is checked '
                'before use. No predictions are cached. The late bulk snapshot hit its own bound; that failure '
                'and its partial manifests remain recorded. The original three-attempt cap remains a launch '
                'block until direct user approval of the proposed five-attempt cap; compute caps remain unchanged.')
            comparison['current_execution_status']='AWAITING_EXPLICIT_ATTEMPT_CAP_EXTENSION'
            for variant in variants:
                if variant['trial_id'] in ['C0','C1']:variant['status']='NOT_HARDWARE_QUALIFIED'
            write('reports/bench_v2_display_data.json',comparison)
    current_accounting=(f'New resource-time accounting: {accounted_chip_hours:.6f} chip-hours committed, including '
        'full reservations for unfinished or uncertain attempts. All attempts remain in the ledger. '
        'Attempts 001–003 failed before any model execution. The infrastructure-only amendment was not '
        'accepted for another launch; the later direct user approval permits five total recorded qualification attempts. '
        '64 total chip-hours, 16 per attempt, candidate family, and correctness thresholds remain unchanged.')
    notification_note=('Ntfy accepted brief approval-needed notices; detailed infrastructure identifiers stay in '
        'chat/local records. The old exact-resource watcher was stopped after the newly authorized resource '
        'was selected. Current work is controlled by the live local assignment and bounded attempt controller. '
        'Every new workload still requires fresh all-worker occupancy checks.')
    lines = [
        'RelationAdapter autoresearch — aggregate-only checkpoint report',
        'Run: ' + ROOT.name,
        'The user lifted the original 24-hour cutoff. Per-attempt timeouts and the total compute budget remain enforced; the currently sealed attempt retains its existing deadline.',
        '',
        'Result: baseline provenance is verified; target isolation and an inference optimization are prepared and CPU-tested. No new complete validation score or quality improvement is claimed. ' + result_status,
        '',
        'Current baseline and conflicts',
        'The current published site is version 68, source b68f51b54ac54c8dabc9d9e8ac714ceb17ea36dd. Its RelationAdapter score and inference metadata are byte-identical across seven local completed-score snapshots. The completed run is the October 14 v5p16_q1_fa0dfd run; inference completed October 15 and corrected-v3 scores were issued October 16. October 26 prompted q0 work is a 13-query diagnostic, excluded as a baseline and not inspected for examples or scores.',
        'Bench v2 validation: supervision 6, pack 8e139f91b083e0ae73b2ed81d8e235460ac2f37d, 13 tasks x 17 queries = 221, native P=1, real condition, one output. General AGENTS.md v5 pack guidance does not supersede this identity. Pack prose describes P=16; the validated model-specific condition explicitly uses direct P=1. Both conflicts are preserved in the identity audit.',
        'The baseline uses a generic instruction. The official paper describes directional editing text. No content captions or benchmark examples were used to author prompts. The baseline remains labeled as a benchmark adaptation, and CUDA-to-TPU parity remains unestablished.',
        '',
        'What changed',
        'C0 separates authorized demonstration/query inputs from query targets. The scorer alone reconstructs query targets after inference. The generic scientific recipe and frozen episode draw are unchanged.',
        'Runtime gates now bind every pinned dependency and a complete transitive environment inventory; executable-cache namespaces include the scientific/source/runtime contract. All fresh output bytes and pixel hashes must match before the scorer reads query targets. Trial accounting preserves uncertain reservations. Full controller and device integration remain hardware-gated.',
        'C1 additionally caches deterministic relation-attention K/V projections once per episode, clears them on every exit, and invalidates on tensor, parameter, normalization, layout, or identity changes. It retains resolution, 24 steps, seed 1000, guidance 3.5, strength 1.0, and one demonstration. Full-model synthetic TPU equality and >=5% warm speed improvement are required before promotion.',
        '',
        'Measured evidence and limits',
        f"{tests['tests']} numerical synthetic CPU tests and {handoff['tests']} runtime/handoff tests passed. These cover exact float32/bfloat16 attention, 72 palette fixtures, preprocessing, cache identity/order, mutation rejection, cleanup, reference fallback gates, full environment identity, all 221 synthetic output bindings, launch selection, and shared budget limits. No validation examples were read.",
        'The additional synthetic test-payload guard test passed: metadata stat remains allowed, while payload opens and directory enumeration are refused. The explicit approval-cap test also passed. Total distinct CPU tests passed: 20.',
        f"A synthetic actual-dimension single-layer CPU profile measured {profile['results'][0]['speedup_projection_only']:.2f}x float32 and {profile['results'][1]['speedup_projection_only']:.2f}x bfloat16 speedup for the repeated projection sub-operation across 24 steps, including cache preparation. This is not a whole-model or TPU speedup. Estimated extra cached K/V storage across 57 layers is 171 MiB in bfloat16, not a measured peak-memory figure.",
        f"Archived inference-call total: {sum(seconds):.3f} seconds ({sum(seconds)/60:.2f} minutes); mean {statistics.mean(seconds):.3f} s/query; median {statistics.median(seconds):.3f} s/query. Staging, model startup, compilation split, scoring time, peak memory, and total chip-hours are not fully recorded. The one-hour end-to-end target and additional capacity needed therefore remain unestablished.",
        current_accounting,
        'Cold attempt 004 reached model execution, but ended without a completed synthetic-output receipt. Startup and first-output compilation are not separately measurable from its partial instrumentation; its growing executable cache proves compilation activity. Twenty synthetic CPU tests and scorer admission do not replace full-model qualification.',
        'Frozen scorer readiness: the original constructor passed with its original certified libraries in a private namespace. Host libraries and shared scorer source remain unchanged. Eleven validation-only pack/GT files were copied to the private us-central2 run prefix and staged locally with exact hashes; no example arrays were inspected. The initial copy was rejected pending destination trust. Read-only IAM checks established private same-project regional access; the retry justification incorrectly said identical bindings, and the recorded correction documents their regional-service-account differences.',
        '',
        'Search and status',
        'Finite preregistered family: preserved B0, target-isolated C0, cached C1, and three directional-text arms at alpha 1, 0.5, 2. Quality arms remain gated because a source-disjoint v6 development set with all 13 metrics is not established. No validation-guided selection occurred. All attempts are retained in trial_ledger.json and trial_events.jsonl.',
        capacity_line,
        assignment_note,
        launch_note,
        notification_note,
        '',
        'Artifacts',
        'fidelity_audit.json: cited method-by-method audit. bench_v2_display_data.json and baseline_aggregate.csv: separate display-ready aggregates, with nulls for unrun candidates. timing_evidence.json: measured fields and explicit unknowns. ../manifests/: weights, source, environment, pack, metric, and artifact identities. ../configs/preregistration.json: fixed selection rules/limits. ../RUNBOOK.txt: reproducible preparation, qualification, inference, scoring, and deadline commands.',
        'The live site, existing rows, shared scorer, shared research source, datasets, and other models were not edited.',
        '',
        'Primary citations', PAPER, 'https://arxiv.org/abs/2506.02528v1', OFFICIAL + 'infer_single.py', OFFICIAL + 'attention_processor.py', OFFICIAL + 'src/pipeline_pe_clone.py',
    ]
    (ROOT / 'reports/REPORT.txt').write_text('\n'.join(lines) + '\n')
    write('reports/trial_ledger.json', [{'trial_id': x['trial_id'], 'label': x['label'], 'status': x['status'],
         'new_validation_episodes': 0, 'new_quality_score': None} for x in variants]
         + [dict(trial_id=name, **trial) for name,trial in budget['trials'].items()])
    print(json.dumps({'report': str(ROOT / 'reports/REPORT.txt'), 'baseline_episodes': 221, 'new_validation_episodes': 0}))


if __name__ == '__main__': main()
